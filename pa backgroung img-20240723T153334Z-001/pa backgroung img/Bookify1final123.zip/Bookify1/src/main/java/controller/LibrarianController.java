package controller;

import model.Employee;
import model.Librarian;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;


public class LibrarianController {
    private BillController billController;
    private BookController bookController;
    private EmployeeController employeeController;
    private Employee user;
    private ArrayList<Librarian> seleceted_lib;
    private ArrayList<Employee> lib;


    public LibrarianController(BillController billController, BookController bookController, EmployeeController employeeController, Employee u) {
        this.user = u;
        this.billController = billController;
        this.bookController = bookController;
        this.employeeController = employeeController;
        seleceted_lib=new ArrayList<>();
        lib=new ArrayList<>();

    }

    public BookController getBookController() {
        return bookController;
    }

    public BillController getBillController() {
        return billController;
    }

    public EmployeeController getEmployeeController() {
        return employeeController;
    }

    public Employee getUser() {
        return user;
    }

    public void setBillController(BillController billController) {
        this.billController = billController;
    }

    public void setBookController(BookController bookController) {
        this.bookController = bookController;
    }

    public void setEmployeeController(EmployeeController employeeController) {
        this.employeeController = employeeController;
    }

    public void setUser(Employee user) {
        this.user = user;
    }

    public ArrayList<Librarian> check_bills(LocalDate userDate) {
        lib = employeeController.getLibList();
        if(lib==null){
            System.out.println("Null lib");
        }
        seleceted_lib = new ArrayList<>();
        // LocalDate localDate;
        if(billController.getBill()==null){
            System.out.println("NUll");
        }
        for (int i = 0; i < billController.getBill().size(); i++) {

            if (userDate.equals(billController.getBill().get(i).getBil_date().toInstant().atZone(ZoneId.systemDefault()).toLocalDate())) {

                String id = billController.getBill().get(i).getLib_username();
                if (employeeController.checkIfLib(id)) {
                    Librarian librarian = check_user(id);
                    if (librarian==null){
                        System.out.println("Selected null");
                    }
                    double t_nritems = 0;
                    int quantityyy = 0;
                    if (librarian != null) {

                        for (int j = 0; j < billController.getBill().get(i).getNr_items(); j++) {
                            t_nritems += billController.getBill().get(i).getSingle_price()[j];
                            quantityyy += billController.getBill().get(i).getQuantity()[j];
                        }
                        librarian.setNr_bills(librarian.getNr_bills() + 1);
                        librarian.setBook_sold(librarian.getBook_sold() + quantityyy);
                        librarian.setTotal_amountMoney(librarian.getTotal_amountMoney() + t_nritems);
                    } else {
                        t_nritems = 0;
                        quantityyy = 0;
                        for (int j = 0; j < billController.getBill().get(i).getNr_items(); j++) {
                            t_nritems += billController.getBill().get(i).getSingle_price()[j];
                            quantityyy += billController.getBill().get(i).getQuantity()[j];
                        }
                        seleceted_lib.add(new Librarian(billController.getBill().get(i).getLib_username(), 1, quantityyy, t_nritems));
                    }
                }
            }

        }

        return seleceted_lib;
    }

    public ArrayList<Librarian> check_bills2(LocalDate userDate,LocalDate userDate2){
        seleceted_lib=new ArrayList<>();
        for (int i=0;i<billController.getBill().size();i++) {
            // LocalDate localDate=bills.get(i).getBillDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            LocalDate d1 = billController.getBill().get(i).getBil_date().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

            if ((userDate.isBefore(d1) || userDate.isEqual(d1)) && (userDate2.isAfter(d1) || userDate2.isEqual(d1))) {
                String id = billController.getBill().get(i).getLib_username();

                if (employeeController.checkIfLib(id)) {
                    Librarian librarian = check_user(id);
                    double t_nritems = 0;
                    int quantityyy = 0;
                    if (librarian != null) {
                        System.out.println("Not null");

                        for (int j = 0; j < billController.getBill().get(i).getNr_items(); j++) {
                            t_nritems += billController.getBill().get(i).getSingle_price()[j];
                            quantityyy += billController.getBill().get(i).getQuantity()[j];
                        }
                        librarian.setNr_bills(librarian.getNr_bills() + 1);
                        librarian.setBook_sold(librarian.getBook_sold() + quantityyy);
                        librarian.setTotal_amountMoney(librarian.getTotal_amountMoney() + t_nritems);
                    }
                    else {
                        t_nritems = 0;
                        quantityyy = 0;
                        for (int j = 0; j < billController.getBill().get(i).getNr_items(); j++) {
                            System.out.println("For");
                            t_nritems += billController.getBill().get(i).getSingle_price()[j];
                            quantityyy += billController.getBill().get(i).getQuantity()[j];
                        }
                        seleceted_lib.add(new Librarian(billController.getBill().get(i).getLib_username(), 1, quantityyy, t_nritems));
                        System.out.println("Added");
                    }

                }
            }

        }
        return seleceted_lib;
    }


    public void showBillList() {
        //   listView.displayEmployees(employeeManager.getBill());
    }
    public Librarian check_user(String username){


        for(int k=0;k<seleceted_lib.size();k++) {
            if (username.equals(seleceted_lib.get(k).getUsername())) {
                return seleceted_lib.get(k);
            }

        }
        return null;

    }




}