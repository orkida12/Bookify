package controller;

import model.Bill;
import model.Book;
import model.Employee;

import java.io.*;
import java.util.ArrayList;
import java.util.Date;

public class BillController {

    private  ArrayList<Bill> bill_arraylist;
    private BookController bookController;
    private ArrayList<Integer> quatity ;
    private ArrayList<String > ISbn;
    private int[] quatity1;
    private String [] ISbn1;


    int nr_of_items;
    private File file;

    public BillController(){
        bill_arraylist=new ArrayList<>();
        //   this.librarianController=librarianController;
        //  this.bookController=bookController;
        //   this.ISbn=new ArrayList<>();
        //   quatity=new ArrayList<>();
        file=new File("Database/bill.dat");
        if(file.exists()){
            readBill();
        }
    }
    private void readBill() {
        try {
            FileInputStream fis = new FileInputStream(file);
            ObjectInputStream ois = new ObjectInputStream(fis);
            bill_arraylist = (ArrayList<Bill>) ois.readObject();
            fis.close();
            ois.close();

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    private void writeBill() {
        try{
            FileOutputStream fos = new FileOutputStream(file);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(bill_arraylist);
            oos.close();
            fos.close();

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    public void addBill(Bill employees){
        bill_arraylist.add(employees);
        writeBill();

    }
    public ArrayList<Bill> getBill() {

        return bill_arraylist;
    }

    public void  newBilNr(int nr){
        quatity1=new int[nr];
        ISbn1=new String[nr];
    }
    public void AddBill(int  nr_items,String[] ISBN,int[] quantity,BookController bookController,Employee user){

        bill_arraylist.add(new Bill(nr_items,ISBN,quantity,bookController,user));
        writeBill();
    }
    public void cretearray(String isbn,int q,int index){
        quatity1[index]=q;
        ISbn1[index]=isbn;
        // quatity.add(q);
        // ISbn.add(isbn);
    }

    public ArrayList<String> getISbn() {
        return ISbn;
    }

    public ArrayList<Integer> getQuatity() {
        return quatity;
    }
    public  int [] ArrayToInt(Object [] o){
        int []array =new int[o.length];
        for (int i = 0; i < o.length; i++) {
            // Assuming each object can be converted to a String representation of an integer
            // If the object is an Integer, you can directly cast it: intArray[i] = (int) objectArray[i];
            array[i] = Integer.parseInt(String.valueOf(o[i]));
        }
        return array;

    }
    public  String[] convertToStringArray(Object[] objectArray) {
        String[] stringArray = new String[objectArray.length];

        for (int i = 0; i < objectArray.length; i++) {
            // Using String.valueOf() to convert each object to a string
            stringArray[i] = String.valueOf(objectArray[i]);
        }

        return stringArray;}

    public int[] getQuatity1() {
        return quatity1;
    }

    public String[] getISbn1() {
        return ISbn1;
    }


}