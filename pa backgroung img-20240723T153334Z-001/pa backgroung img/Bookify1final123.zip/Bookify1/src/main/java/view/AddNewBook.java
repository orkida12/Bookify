package view;

import controller.BillController;
import controller.BookController;
import controller.EmployeeController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import model.Employee;

public class AddNewBook {
    private Employee currentUser;
    private BookController bookController;
    private BillController billController;
    private EmployeeController employeeController;

    public AddNewBook(BillController billController, BookController bookController,
                      EmployeeController employeeController, Employee currentUser) {
        this.currentUser = currentUser;
        this.billController = billController;
        this.bookController = bookController;
        this.employeeController=employeeController;
        // Add employeeController if needed
    }

    public Scene viewSupply(Stage stage, String ISBN) {
        VBox mainPane = new VBox();
        mainPane.setAlignment(Pos.CENTER);
        mainPane.setPadding(new Insets(11.5, 11.5, 11.5, 11.5));
        mainPane.setSpacing(10);

        HBox headerBox = createHeaderBox();
        GridPane gridPane = createGridPane(stage,ISBN);

        mainPane.getChildren().addAll(headerBox, gridPane);
        Image backgroundImage = new Image("Photo/Fotohomepage1.jpg");

        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);

        // Set the background image to the grid pane
        mainPane.setBackground(new Background(background));

        Scene scene = new Scene(mainPane, 1071, 771);
        return scene;
    }

    private HBox createHeaderBox() {
        HBox headerBox = new HBox();
        headerBox.setAlignment(Pos.CENTER);
        Label addBookLabel = new Label("Add Book");
        addBookLabel.setStyle("-fx-font-size: 20px;"); // Set a larger font size

        headerBox.getChildren().add(addBookLabel);
        return headerBox;
    }

    private GridPane createGridPane(Stage stage,String ISBN) {
        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setHgap(8);
        gridPane.setVgap(5);

        // TextFields
        TextField title =  createTextFieldWithPrompt("Title");
        title.setStyle("-fx-font-size: 20px;"); // Set a larger font size
        TextField author = createTextFieldWithPrompt("Author");
        author.setStyle("-fx-font-size: 20px;"); // Set a larger font size

        TextField category = createTextFieldWithPrompt("Category");
        category.setStyle("-fx-font-size: 20px;"); // Set a larger font size

        TextField supplier = createTextFieldWithPrompt("Supplier");
        supplier.setStyle("-fx-font-size: 20px;"); // Set a larger font size
        TextField sellingPrice = createTextFieldWithPrompt("Selling Price");
        sellingPrice.setStyle("-fx-font-size: 20px;"); // Set a larger font size

        TextField purchasePrice = createTextFieldWithPrompt("Purchase Price");
        purchasePrice.setStyle("-fx-font-size: 20px;"); // Set a larger font size

        TextField stock = createTextFieldWithPrompt("Stock");
        stock.setStyle("-fx-font-size: 20px;"); // Set a larger font size


        stock.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.isEmpty()) {
                validateStock(newValue);
            }
        });

        author.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.isEmpty()) {
                validateAuthor(newValue);
            }
        });

        category.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.isEmpty()) {
                validateCategory(newValue);
            }
        });


        purchasePrice.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.isEmpty()) {
                validatePurchasePrice(newValue);
            }
        });

        sellingPrice.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.isEmpty()) {
                validateSellingPrice(newValue);
            }
        });

        // Add TextFields to GridPane
        gridPane.add(title, 0, 0);
        gridPane.add(author, 0, 1);
        gridPane.add(category, 0, 2);
        gridPane.add(supplier, 0, 3);
        gridPane.add(sellingPrice, 1, 0);
        gridPane.add(purchasePrice, 1, 1);
        gridPane.add(stock, 1, 2);

        // Add Button
        Button add = createStyledButton("Add");
        add.setStyle("-fx-font-size: 20px;-fx-background-color: #90caf9; -fx-text-fill: white;");



        add.setOnAction(e -> {

            String title1 = title.getText();
            String author1 = author.getText();
            String categoty = category.getText();
            String supplyer = supplier.getText();
            double pr_priece = 0;
            double s_price = 0;
            int st = 0;

            try {
                String p_priece = purchasePrice.getText();
                pr_priece = Double.parseDouble(p_priece);
                s_price = Double.parseDouble(sellingPrice.getText());
                st = Integer.parseInt(stock.getText());


                bookController.create_new_book(ISBN, title1, categoty, supplyer, pr_priece, s_price, author1, st);

                Alert infromation = new Alert(Alert.AlertType.INFORMATION);
                infromation.setHeaderText("The  book was added successfully");
                infromation.showAndWait();
            } catch (NumberFormatException exception) {
                Alert error = new Alert(Alert.AlertType.ERROR);
                error.setHeaderText("Enter a number!");
                error.showAndWait();

                // ManagerHomePageView managerHomePageView=new ManagerHomePageView(managerController);
                //  stage.setScene(managerHomePageView.showView(stage));
            }
            SupplyTheStoreView a=new SupplyTheStoreView(this.billController,this.bookController,this.employeeController,this.currentUser);
            stage.setScene(a.viewSupply(stage));

        });
        gridPane.add(add, 1, 3);



        return gridPane;

    }

    private TextField createTextFieldWithPrompt(String prompt) {
        TextField textField = new TextField();
        textField.setPromptText(prompt);

        // Add a listener to hide the prompt text when the user starts typing
        textField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.isEmpty()) {
                textField.setPromptText("");
            } else {
                textField.setPromptText(prompt);
            }
        });

        return textField;
    }

    private Button createStyledButton(String text) {
        Button button = new Button(text);
        button.setStyle("-fx-background-color: #90caf9; -fx-text-fill: white;");
        return button;
    }

    private void validateStock(String stock) {
        if (!stock.matches("\\d*")) {
            showAlert("Invalid Stock", "Stock should contain only numbers.");
        }
    }

    private void validateAuthor(String author) {
        if (!author.matches("[a-zA-Z]*")) {
            showAlert("Invalid Author", "Author should contain only letters.");
        }
    }

    private void validatePurchasePrice(String purchasePrice) {
        if (!purchasePrice.matches("\\d*")) {
            showAlert("Invalid Purchase Price", "Purchase Price should contain only numbers.");
        }
    }

    private void validateCategory(String category) {
        if (!category.matches("[a-zA-Z]*")) {
            showAlert("Invalid Category", "Category should contain only letters.");
        }
    }

    private void validateSellingPrice(String sellingPrice) {
        if (!sellingPrice.matches("\\d*")) {
            showAlert("Invalid Selling Price", "Selling Price should contain only numbers.");
        }
    }

    // Helper method to show an alert
    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

}
