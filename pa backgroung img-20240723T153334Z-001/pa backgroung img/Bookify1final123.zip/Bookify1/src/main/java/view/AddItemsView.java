package view;

import controller.BillController;
import controller.BookController;
import controller.EmployeeController;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.beans.binding.BooleanBinding;
import model.Employee;


public class AddItemsView  {
    BookController bookController;
    BillController billController;
    EmployeeController employeeController;
    Employee crrentUser;
    AddItemsView(BillController billController,BookController bookController,EmployeeController employeeController,Employee currentUser){
        this.billController=billController;
        this.bookController=bookController;
        this.employeeController=employeeController;
        this.crrentUser=currentUser;
    }

    public Scene start(Stage primaryStage) {
        // Set the title for the stage
        primaryStage.setTitle("Add Items");

        // Create a GridPane for layout
        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setPadding(new Insets(25, 25, 25, 25));

        // Create a label and add it to the GridPane at position (0, 0)
        Label label = new Label("Enter No. of Items:");
        label.setStyle("-fx-font-size: 20px;"); // Set button color and text color

        gridPane.add(label, 0, 0);

        // Create a TextField with default prompt text and add it to the GridPane at position (1, 0)
        TextField numberOfItems = createTextFieldWithPrompt("No. of Items");
        gridPane.add(numberOfItems, 1, 0);

        // Create a button and add it to the GridPane at position (1, 1)
        Button addButton = createStyledButton("Add");
        gridPane.add(addButton, 1, 1);
        Button backButton = createStyledButton("Back");
        gridPane.add(backButton, 2, 1);
        Image backgroundImage = new Image("Photo/Fotohomepage1.jpg");

        // Create a background image
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);

        // Set the background image to the grid pane
        gridPane.setBackground(new Background(background));

        // Create a Scene with the GridPane as the root and set its size
        Scene scene = new Scene(gridPane, 1079, 771);

        addButton.setDisable(true);

        numberOfItems.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.isEmpty()) {
                validatenumberOfItems(newValue);
            }
        });

        BooleanBinding isISBNEmpty = numberOfItems.textProperty().isEmpty();
        addButton.disableProperty().bind(isISBNEmpty);
        backButton.setOnAction(e->{

            if(crrentUser.getNr()==0) {
                AdministratorHomePageView hv2 = new AdministratorHomePageView(billController,bookController,employeeController,crrentUser);
                primaryStage.setTitle("AdministratorHomePageView");

                primaryStage.setScene(hv2.showView(primaryStage));
                System.out.println("0");
            }
            else if (crrentUser.getNr()==1){
                ManagerHomePageView homePageView=new ManagerHomePageView(billController,bookController,employeeController,crrentUser);
                primaryStage.setTitle("ManagerHomePage");
                primaryStage.setScene(homePageView.showView(primaryStage));
            }else{
                LibrarianHomePageView homePageView=new LibrarianHomePageView(billController,bookController,employeeController,crrentUser);
                primaryStage.setTitle("LibrarianHomePageView");
                primaryStage.setScene(homePageView.showView(primaryStage));
            }
            System.out.println("898");

        });

        addButton.setOnAction(e->{
            int nrItems=Integer.parseInt(numberOfItems.getText());

            AddNewBillView bill=new AddNewBillView(billController, bookController,  employeeController, crrentUser);
            billController.newBilNr(nrItems);
            primaryStage.setScene(bill.showAddBill(primaryStage,nrItems));

        });

/*BillAddButtonView buttun1=new BillAddButtonView(billController,bookController,employeeController,crrentUser);
buttun1.showView(primaryStage,Integer.parseInt(numberOfItems.getText()));*/
        // Set the Scene for the primaryStage and display it
        return scene;
    }


    private TextField createTextFieldWithPrompt(String prompt) {
        TextField textField = new TextField();
        textField.setStyle("-fx-font-size: 20px;"); // Set button color and text color

        textField.setPromptText(prompt);

        // Add a listener to hide the prompt text when the user starts typing
        textField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.isEmpty()) {
                textField.setPromptText("");
            } else {
                textField.setPromptText(prompt);
            }
        });

        return textField;
    }

    private Button createStyledButton(String text) {
        Button button = new Button(text);
        button.setStyle("-fx-font-size: 20px;-fx-background-color: #90caf9; -fx-text-fill: white;"); // Set button color and text color
        return button;
    }

    private void validatenumberOfItems(String sellingPrice) {
        if (!sellingPrice.matches("\\d*")) {
            showAlert("Invalid Number", "This TextField should contain only numbers.");
        }
    }

    // Helper method to show an alert
    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

}
