package view;

import controller.BillController;
import controller.BookController;
import controller.EmployeeController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import model.Employee;

import java.text.SimpleDateFormat;
import java.util.Date;

public class ShowBookView {
    private Employee currentUser;
    private BookController bookController;
    private BillController billController;
    private EmployeeController employeeController;

    public ShowBookView(BillController billController, BookController bookController, EmployeeController employeeController, Employee currentUser) {
        this.currentUser = currentUser;
        this.billController = billController;
        this.bookController = bookController;
        this.employeeController = employeeController;


    }

    public Scene viewSupply(Stage stage, String isbn, int index) {
        VBox vBox = new VBox(10);
        vBox.setAlignment(Pos.CENTER);
        vBox.setPadding(new Insets(11.5, 11.5, 11.5, 11.5));

        Label isbnLabel = new Label("ISBN: " + isbn);
        isbnLabel.setStyle("-fx-font-size: 20px"); // Set button color and text color

        Label titleLabel = new Label("Title: " + bookController.getTitle(index));
        titleLabel.setStyle("-fx-font-size: 20px"); // Set button color and text color

        Label categoryLabel = new Label("Category: " + bookController.getCategory(index));
        categoryLabel.setStyle("-fx-font-size: 20px"); // Set button color and text color

        Label supplierLabel = new Label("Supplier: " + bookController.getSupplier(index));
        supplierLabel.setStyle("-fx-font-size: 20px"); // Set button color and text color

        Label purchasePriceLabel = new Label("Purchase Price: " + bookController.getPurchesPrice(index));
        purchasePriceLabel.setStyle("-fx-font-size: 20px"); // Set button color and text color

        Label sellingPriceLabel = new Label("Selling Price: " + bookController.getSellingPrice(index));
        sellingPriceLabel.setStyle("-fx-font-size: 20px"); // Set button color and text color

        Label authorLabel = new Label("Author: " + bookController.getAuthor(index));
        authorLabel.setStyle("-fx-font-size: 20px"); // Set button color and text color

        Label stockLabel = new Label("Stock: " + bookController.getStock(index));
        stockLabel.setStyle("-fx-font-size: 20px"); // Set button color and text color


        vBox.getChildren().addAll(isbnLabel, titleLabel, categoryLabel, supplierLabel,
                purchasePriceLabel, sellingPriceLabel, authorLabel, stockLabel);

        Button backButton = createStyledButton("Back");
        backButton.setOnAction(e -> {
            if(currentUser.getNr()==0) {
                AdministratorHomePageView hv2 = new AdministratorHomePageView(billController,bookController,employeeController,currentUser);
                stage.setTitle("AdministratorHomePageView");

                stage.setScene(hv2.showView(stage));
                System.out.println("0");
            }
            else if (currentUser.getNr()==1){
                ManagerHomePageView homePageView=new ManagerHomePageView(billController,bookController,employeeController,currentUser);
                stage.setTitle("ManagerHomePage");
                stage.setScene(homePageView.showView(stage));
            }else{
                LibrarianHomePageView homePageView=new LibrarianHomePageView(billController,bookController,employeeController,currentUser);
                stage.setTitle("LibrarianHomePageView");
                stage.setScene(homePageView.showView(stage));
            }
            System.out.println("898");


        });

        vBox.getChildren().add(backButton);
        Image backgroundImage = new Image("Photo/Fotohomepage1.jpg");

        // Create a background image
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);

        // Set the background image to the grid pane
        vBox.setBackground(new Background(background));
        Scene scene = new Scene(vBox, 1079, 771);
        return scene;
    }

    private Button createStyledButton(String text) {
        Button button = new Button(text);
        button.setStyle("-fx-font-size: 20px;-fx-background-color: #90caf9; -fx-text-fill: white;"); // Set button color and text color
        return button;
}
}