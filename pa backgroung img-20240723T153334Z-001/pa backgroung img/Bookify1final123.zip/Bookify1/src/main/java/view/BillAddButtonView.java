package view;


import controller.BillController;
import controller.BookController;
import controller.EmployeeController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import model.Employee;



public class BillAddButtonView {
    private BillController billController;
    private BookController bookController;
    private EmployeeController employeeController;
    private Employee currentUser;
    private String UserName;

    public BillAddButtonView(BillController billController, BookController bookController, EmployeeController employeeController, Employee currentUser){
        this.billController=billController;
        this.bookController=bookController;
        this.currentUser=currentUser;
        this.employeeController=employeeController;
    }

    public Scene showView(Stage primaryStage,int nr_ofitems){
        StackPane stackPane = new StackPane();
        stackPane.setAlignment(Pos.CENTER);
        stackPane.setPadding(new Insets(25, 25, 25, 25));

        Button addBillButton = createStyledButton("Add Bill");
        stackPane.getChildren().add(addBillButton);
        Image backgroundImage = new Image("Photo/Fotohomepage1.jpg");

        // Create a background image
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);

        // Set the background image to the grid pane
        stackPane.setBackground(new Background(background));

        Scene scene = new Scene(stackPane, 1079, 771);

        addBillButton.setOnAction(e->{
            //billController.AddBill(nr_ofitems,billController.getISbn().toArray(),billController.getQuatity().toArray(),bookController,currentUser);
            billController.AddBill(nr_ofitems,billController.getISbn1(),billController.getQuatity1(),bookController,currentUser);
            System.out.println(billController.getBill());
            for (int i=0;i<billController.getBill().size();i++){
                billController.getBill().get(i).writeToBill();
            }
            if(currentUser.getNr()==0) {
                AdministratorHomePageView hv2 = new AdministratorHomePageView(billController,bookController,employeeController,currentUser);
                primaryStage.setTitle("AdministratorHomePageView");

                primaryStage.setScene(hv2.showView(primaryStage));
                System.out.println("0");
            }
            else if (currentUser.getNr()==1){
                ManagerHomePageView homePageView=new ManagerHomePageView(billController,bookController,employeeController,currentUser);
                primaryStage.setTitle("ManagerHomePage");
                primaryStage.setScene(homePageView.showView(primaryStage));
            }else{
                LibrarianHomePageView homePageView=new LibrarianHomePageView(billController,bookController,employeeController,currentUser);
                primaryStage.setTitle("LibrarianHomePageView");
                primaryStage.setScene(homePageView.showView(primaryStage));
            }
        });

        return scene;
    }

    private Button createStyledButton(String text) {
        Button button = new Button(text);
        button.setStyle("-fx-font-size: 70px;-fx-background-color: #90caf9; -fx-text-fill: white;"); // Set button color and text color
        return button;
    }
}