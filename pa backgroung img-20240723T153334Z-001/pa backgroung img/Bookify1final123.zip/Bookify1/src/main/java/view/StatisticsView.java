package view;

import controller.AdministratorController;
import controller.BillController;
import controller.BookController;
import controller.EmployeeController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import model.Bill;
import model.Book;
import model.Employee;

public class StatisticsView {
    private BookController bookController;
    private BillController billController;
    private EmployeeController employeeController;
    private Employee user;
    private LogInView a = new LogInView();
    public StatisticsView(BillController billController, BookController bookController, EmployeeController employeeController, Employee user) {
        this.billController = billController;
        this.bookController = bookController;
        this.employeeController = employeeController;
        this.user = user;
    }
    AdministratorController employeeManage = new AdministratorController(a);

    public Scene ShowStatistic(Stage stage) {

        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setPadding(new Insets(11.5, 11.5, 11.5, 11.5));
        gridPane.setHgap(8);
        gridPane.setVgap(5);

        // Labels and information in a VBox
        VBox vbox = new VBox(10);
        vbox.setAlignment(Pos.CENTER);

        Label Total_book_sold = new Label("Total Books Sold: " + employeeManage.totalbooksold());
        Total_book_sold.setStyle("-fx-font-size: 20px;");

        Label Most_Sold_Book = new Label("Most Sold Book: " + bookController.getMostSold().getTitle()+ " (" + bookController.getMostSold().getISBN() + ")");
        Most_Sold_Book.setStyle("-fx-font-size: 20px;");

        Label Least_Sold_Book = new Label("Least Sold Book: " + bookController.getLeastSold().getTitle() + " (" + bookController.getLeastSold().getISBN() + ")");
        Least_Sold_Book.setStyle("-fx-font-size: 20px;");

        Label Total_book_bought = new Label("Total Books Bought: " + employeeManage.totalbookbought());
        Total_book_bought.setStyle("-fx-font-size: 20px;");


        vbox.getChildren().addAll(Total_book_sold, Most_Sold_Book, Least_Sold_Book, Total_book_bought);
        gridPane.add(vbox, 0, 0);

        // Back button
        Button back = new Button("Back");
        back.setStyle("-fx-font-size: 20px;-fx-background-color: #90caf9; -fx-text-fill: white;"); // Set button color and text color
        gridPane.add(back, 0, 1);

        back.setOnAction(e -> {

            if(user.getNr()==0) {
                AdministratorHomePageView hv2 = new AdministratorHomePageView(billController,bookController,employeeController,user);
                stage.setTitle("AdministratorHomePageView");

                stage.setScene(hv2.showView(stage));
                System.out.println("0");
            }
            else if (user.getNr()==1){
                ManagerHomePageView homePageView=new ManagerHomePageView(billController,bookController,employeeController,user);
                stage.setTitle("ManagerHomePage");
                stage.setScene(homePageView.showView(stage));
            }else{
                LibrarianHomePageView homePageView=new LibrarianHomePageView(billController,bookController,employeeController,user);
                stage.setTitle("LibrarianHomePageView");
                stage.setScene(homePageView.showView(stage));
            }
        });
        Image backgroundImage = new Image("Photo/Fotohomepage1.jpg");

        // Create a background image
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);

        // Set the background image to the grid pane
        gridPane.setBackground(new Background(background));

        Scene scene = new Scene(gridPane, 1079, 771);
        return scene;
}
}