package view;

import controller.BillController;
import controller.BookController;
import controller.EmployeeController;
import controller.LibrarianController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import model.Employee;
import model.Librarian;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class PeriodDateView {
    private BillController billController;
    private BookController bookController;
    private EmployeeController employeeController;
    private Employee user;

    public PeriodDateView(BillController billController, BookController bookController,
                          EmployeeController employeeController, Employee user) {
        this.billController = billController;
        this.bookController = bookController;
        this.employeeController = employeeController;
        this.user = user;
    }

    public Scene showView(Stage stage, LibrarianController librarianController) {
        GridPane gridPane1 = new GridPane();
        gridPane1.setAlignment(Pos.CENTER);
        gridPane1.setPadding(new Insets(11.5, 11.5, 11.5, 11.5));
        gridPane1.setHgap(8);
        gridPane1.setVgap(5);

        Label label1 = new Label("Enter the first date in the form of MM/dd/yyyy");
        label1.setStyle("-fx-font-size: 20px;"); // Set a larger font size

        Label label2 = new Label("Enter the second date in the form of MM/dd/yyyy");
        label2.setStyle("-fx-font-size: 20px;"); // Set a larger font size

        TextField date = new TextField();
        date.setStyle("-fx-font-size: 20px;"); // Set a larger font size

        TextField date2 = new TextField();
        date2.setStyle("-fx-font-size: 20px;"); // Set a larger font size

        HBox hBox1 = new HBox();
        hBox1.getChildren().addAll(label1, date);

        date.setPromptText("Enter the date.");

        date.setPrefColumnCount(10);

        HBox hbox2 = new HBox();
        hbox2.getChildren().addAll(label2, date2);

        date2.setPromptText("Enter the date.");
        date2.setPrefColumnCount(10);

        Button get = new Button("Get");
        get.setStyle("-fx-font-size: 20px;-fx-background-color: #90caf9; -fx-text-fill: white;");

        Button backButton = new Button("Back");
        backButton.setStyle("-fx-font-size: 20px;-fx-background-color: #90caf9; -fx-text-fill: white;");


        Lib_Show_result libShowResult = new Lib_Show_result(billController, bookController, employeeController, user);

        get.setOnAction(e -> {
            try {
                String date1 = date.getText();
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
                LocalDate userDate = LocalDate.parse(date1, formatter);

                String date3 = date2.getText();
                DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("MM/dd/yyyy");
                LocalDate userDate2 = LocalDate.parse(date3, formatter2);

                ArrayList<Librarian> selected_librarian2 = librarianController.check_bills2(userDate, userDate2);
                stage.setScene(libShowResult.ShowResult(stage, selected_librarian2));
            } catch (Exception exception) {
                showAlert("Invalid date format. Please enter dates in the format MM/dd/yyyy.");
                exception.printStackTrace();
            }
        });

        backButton.setOnAction(event -> {
            LibrarianPerformance librarianPerformance=new LibrarianPerformance(billController,bookController,employeeController,user);
            stage.setScene(librarianPerformance.librarian_preformance_view(stage, librarianController));
        });

        HBox buttonBox = new HBox();
        buttonBox.getChildren().addAll(get, backButton);
        buttonBox.setAlignment(Pos.CENTER_RIGHT);
        buttonBox.setSpacing(10);

        gridPane1.add(label1, 0, 0);
        gridPane1.add(hBox1, 0, 1);
        gridPane1.add(label2, 0, 2);
        gridPane1.add(hbox2, 0, 3);
        gridPane1.add(buttonBox, 0, 4);
        Image backgroundImage = new Image("Photo/Fotohomepage1.jpg");

        // Create a background image
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);

        // Set the background image to the grid pane
        gridPane1.setBackground(new Background(background));

        return new Scene(gridPane1, 1079, 771);
    }

    // Helper method to show an alert
    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setHeaderText(message);
        alert.showAndWait();
}
}