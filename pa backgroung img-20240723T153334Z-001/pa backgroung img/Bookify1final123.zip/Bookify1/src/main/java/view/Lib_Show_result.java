package view;

import controller.BillController;
import controller.BookController;
import controller.EmployeeController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import model.Employee;
import model.Librarian;

import java.util.ArrayList;

public class Lib_Show_result {
    private BillController billController;
    private BookController bookController;
    private EmployeeController employeeController;
    private Employee user;

    public Lib_Show_result(BillController billController, BookController bookController,
                           EmployeeController employeeController, Employee user) {
        this.billController = billController;
        this.bookController = bookController;
        this.user = user;
        this.employeeController = employeeController;
    }

    public Scene ShowResult(Stage stage, ArrayList<Librarian> librariansA) {
        GridPane gridPane = new GridPane();

        gridPane.setAlignment(Pos.CENTER);
        gridPane.setPadding(new Insets(11.5, 11.5, 11.5, 11.5));
        gridPane.setHgap(8);
        gridPane.setVgap(5);

        // Create labels for header
        Label nameLabel = createBoldLabel("Name");
        Label profitLabel = createBoldLabel("Profit");
        Label noBillsLabel = createBoldLabel("No.Bills");
        Label booksSoldLabel = createBoldLabel("Books Sold");

        // Add header labels to gridPane
        gridPane.add(nameLabel, 0, 0);
        gridPane.add(noBillsLabel, 1, 0);
        gridPane.add(booksSoldLabel, 2, 0);
        gridPane.add(profitLabel, 3, 0);

        Label name1, no_bills1, bookSold1, profit1;
        for (int i = 0; i < librariansA.size(); i++) {
            // Retrieve librarian information
            Librarian librarian = librariansA.get(i);

            // Create labels for librarian details
            name1 = new Label(librarian.getUsername());
            no_bills1 = new Label(Integer.toString(librarian.getNr_bills()));
            bookSold1 = new Label(Integer.toString(librarian.getBook_sold()));
            profit1 = new Label(Double.toString(librarian.getTotal_amountMoney()));

            // Add labels for librarian details to gridPane
            gridPane.add(name1, 0, (i + 1));
            gridPane.add(no_bills1, 1, (i + 1));
            gridPane.add(bookSold1, 2, (i + 1));
            gridPane.add(profit1, 3, (i + 1));
        }

        // Create and configure the back button
        Button backButton = new Button("HomePage");
        backButton.setStyle("-fx-font-size: 20px;-fx-background-color: #90caf9; -fx-text-fill: white;");

        backButton.setOnAction(event -> {



            if(user.getNr()==0) {
                AdministratorHomePageView hv2 = new AdministratorHomePageView(billController,bookController,employeeController,user);
                stage.setTitle("AdministratorHomePageView");

                stage.setScene(hv2.showView(stage));
                System.out.println("0");
            }
            else if (user.getNr()==1){
                ManagerHomePageView homePageView=new ManagerHomePageView(billController,bookController,employeeController,user);
                stage.setTitle("ManagerHomePage");
                stage.setScene(homePageView.showView(stage));
            }else{
                LibrarianHomePageView homePageView=new LibrarianHomePageView(billController,bookController,employeeController,user);
                stage.setTitle("LibrarianHomePageView");
                stage.setScene(homePageView.showView(stage));
            }
        });

        // Add back button to gridPane
        gridPane.add(backButton, 0, (librariansA.size() + 2)); // Adjust row position
        Image backgroundImage = new Image("Photo/Fotohomepage1.jpg");

        // Create a background image
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);

        // Set the background image to the grid pane
        gridPane.setBackground(new Background(background));
        return new Scene(gridPane, 1079, 771);
    }

    private Label createBoldLabel(String text) {
        Label label = new Label(text);
        label.setStyle("-fx-font-size: 20px;-fx-font-weight: bold;");
        return label;
}
}