package view;

import controller.AdministratorController;
import controller.BillController;
import controller.BookController;
import controller.EmployeeController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import model.Employee;
import view.LogInView;

import java.time.LocalDate;

public class IncomeCostView {
    private Employee currentUser;
    private BookController bookController;
    private BillController billController;
    private EmployeeController employeeController;
    private LogInView a = new LogInView();

    public IncomeCostView(BillController billController, BookController bookController, EmployeeController employeeController, Employee currentUser) {
        this.currentUser = currentUser;
        this.billController = billController;
        this.bookController = bookController;
        this.employeeController = employeeController;
    }

    public Scene showView(Stage stage, long days) {
        AdministratorController employeeManage = new AdministratorController(a);

        stage.setTitle("Finance Report");

        GridPane financialDetailsGrid = new GridPane();
        financialDetailsGrid.setAlignment(Pos.CENTER);

        financialDetailsGrid.setPadding(new Insets(10, 10, 10, 10));

        financialDetailsGrid.setVgap(8);
        financialDetailsGrid.setHgap(10);
Label l1=new Label("Total Books Sold:");
        Label l2=new Label("Total Income:");
        l1.setStyle("-fx-font-size: 20px;");
        l2.setStyle("-fx-font-size: 20px;"); // Set a larger font size
// Set a larger font size

        // Income Section
        financialDetailsGrid.add(l1, 0, 3);
        financialDetailsGrid.add(l2, 0, 4);

        TextField totalBooksSoldField = new TextField();
        totalBooksSoldField.setStyle("-fx-font-size: 20px;");

        totalBooksSoldField.setEditable(false); // Make it read-only
        totalBooksSoldField.setText(String.valueOf(employeeManage.totalbooksold())); // Set a fixed value for total books sold

        TextField totalIncomeField = new TextField();
        totalIncomeField.setStyle("-fx-font-size: 20px;");

        totalIncomeField.setEditable(false); // Make it read-only
        totalIncomeField.setText(String.valueOf(employeeManage.sumofpricesold())); // Set a fixed value for total income

        financialDetailsGrid.add(totalBooksSoldField, 1, 3);
        financialDetailsGrid.add(totalIncomeField, 1, 4);

        // Button
        Button backButton = new Button("Back");
        backButton.setMinSize(150, 50); // Set a fixed size for all buttons

        financialDetailsGrid.add(backButton, 1, 0); // Span 2 columns for the button

        backButton.setOnAction(e -> {
            FinanceView a = new FinanceView(billController, bookController, employeeController, currentUser);
            stage.setScene(a.showView(stage));
        });
       Label l3= new Label("Finance Report");
        financialDetailsGrid.add(l3, 0, 0);
        l3.setStyle("-fx-font-size: 20px;");


        // Cost Section
       Label l4= new Label("Total Employees:");
       Label l5= new Label("Total Wage Cost:");
        Label l6 =new Label("Total Books Bought:");
        Label l7=new Label("Total Book Cost:");
        Label l8=new Label("Total Cost:");
        Label l9=new Label("Result:");
        l4.setStyle("-fx-font-size: 20px;");l5.setStyle("-fx-font-size: 20px;");l6.setStyle("-fx-font-size: 20px;");
        l7.setStyle("-fx-font-size: 20px;");l8.setStyle("-fx-font-size: 20px;");
        l9.setStyle("-fx-font-size: 20px;");
        financialDetailsGrid.add(l4, 2, 0);
        financialDetailsGrid.add(l5, 2, 1);
        financialDetailsGrid.add(l6, 2, 2);
        financialDetailsGrid.add(l7, 2, 3);
        financialDetailsGrid.add(l8, 2, 4);

        financialDetailsGrid.add(l9, 0, 2);




        TextField totalEmployeesField = new TextField();
        totalEmployeesField.setStyle("-fx-font-size: 20px;");
        totalEmployeesField.setEditable(false); // Make it read-only
        totalEmployeesField.setText(String.valueOf(employeeManage.getArraySize())); // Set a fixed value for total employees

        TextField totalWageCostField = new TextField();
        totalWageCostField.setStyle("-fx-font-size: 20px;");

        totalWageCostField.setEditable(false); // Make it read-only
        totalWageCostField.setText(String.valueOf(employeeManage.calculateTotalSalary())); // Set a fixed value for total wage cost

        TextField totalBooksBoughtField = new TextField();
        totalBooksBoughtField.setStyle("-fx-font-size: 20px;");

        totalBooksBoughtField.setEditable(false); // Make it read-only
        totalBooksBoughtField.setText(String.valueOf(employeeManage.totalbookbought())); // Set a fixed value for total books bought

        TextField totalBookCostField = new TextField();
        totalBookCostField.setStyle("-fx-font-size: 20px;");

        totalBookCostField.setEditable(false); // Make it read-only
        totalBookCostField.setText(String.valueOf(employeeManage.sumtotalbookbought())); // Set a fixed value for total book cost

        TextField totalCostField = new TextField();
        totalCostField.setStyle("-fx-font-size: 20px;");

        totalCostField.setEditable(false); // Make it read-only
        totalCostField.setText(String.valueOf(employeeManage.calculateTotalSalary() + employeeManage.sumtotalbookbought()));

        TextField result = new TextField();
        result.setStyle("-fx-font-size: 20px;");

        result.setEditable(false); // Make it read-only
        result.setText(String.valueOf(employeeManage.sumofpricesold()-(employeeManage.calculateTotalSalary() + employeeManage.sumtotalbookbought())));

        // Set a fixed value for total cost

        financialDetailsGrid.add(totalEmployeesField, 3, 0);
        financialDetailsGrid.add(totalWageCostField, 3, 1);
        financialDetailsGrid.add(totalBooksBoughtField, 3, 2);
        financialDetailsGrid.add(totalBookCostField, 3, 3);
        financialDetailsGrid.add(totalCostField, 3, 4);
        financialDetailsGrid.add(result, 1, 2);

        Image backgroundImage = new Image("Photo/Fotohomepage1.jpg");

        // Create a background image
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);

        // Set the background image to the grid pane
        financialDetailsGrid.setBackground(new Background(background));

        Scene financialDetailsScene = new Scene(financialDetailsGrid, 1079, 771);

        // Additional styling for better appearance
        backButton.setStyle("-fx-background-color: #90caf9; -fx-text-fill: white;"); // Set button color and text color

        return financialDetailsScene;
}
}