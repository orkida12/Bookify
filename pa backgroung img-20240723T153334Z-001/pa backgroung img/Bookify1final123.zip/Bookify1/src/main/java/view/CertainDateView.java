package view;

import controller.BillController;
import controller.BookController;
import controller.EmployeeController;
import controller.LibrarianController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import model.Employee;
import model.Librarian;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class CertainDateView {
    private BookController bookController;
    private BillController billController;
    private EmployeeController employeeController;
    private Employee user;

    public CertainDateView(BillController billController, BookController bookController,
                           EmployeeController employeeController, Employee user) {
        this.billController = billController;
        this.bookController = bookController;
        this.employeeController = employeeController;
        this.user = user;
    }

    public Scene ShowCertainDate(Stage stage, LibrarianController librarianController) {
        GridPane gridPane1 = new GridPane();
        gridPane1.setAlignment(Pos.CENTER);
        gridPane1.setPadding(new Insets(20));
        gridPane1.setHgap(8);
        gridPane1.setVgap(10);

        Label instructionsLabel = new Label("Enter the date in the form of MM/dd/yyyy");
        instructionsLabel.setStyle("-fx-font-size: 20px;"); // Set a larger font size

        TextField date = new TextField();
        date.setPromptText("Enter the date");
        date.setStyle("-fx-font-size: 20px;"); // Set a larger font size


        Button get = createStyledButton("Get");

        Button back = createStyledButton("Back");

        HBox buttonBox = new HBox(10, get, back);
        buttonBox.setAlignment(Pos.CENTER);

        gridPane1.add(instructionsLabel, 0, 0);
        gridPane1.add(date, 0, 1);
        gridPane1.add(buttonBox, 0, 2);

        Lib_Show_result libShowResult = new Lib_Show_result(billController, bookController, employeeController, user);

        get.setOnAction(event -> {
            try {
                String date1 = date.getText();
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
                LocalDate userDate = LocalDate.parse(date1, formatter);

                ArrayList<Librarian> selected_librarian = librarianController.check_bills(userDate);

                stage.setScene(libShowResult.ShowResult(stage, selected_librarian));
            } catch (Exception exception) {
                showAlert("Invalid date format. Please enter a date in the format MM/dd/yyyy.");
                exception.printStackTrace();
            }
        });

        back.setOnAction(event -> {
            LibrarianPerformance librarianPerformance=new LibrarianPerformance(billController,bookController,employeeController,user);
            stage.setScene(librarianPerformance.librarian_preformance_view(stage, librarianController));

        });
        Image backgroundImage = new Image("Photo/Fotohomepage1.jpg");

        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);

        // Set the background image to the grid pane
        gridPane1.setBackground(new Background(background));

        Scene scene = new Scene(gridPane1, 1079, 771);
        return scene;
    }

    private Button createStyledButton(String text) {
        Button button = new Button(text);
        button.setStyle("-fx-font-size: 20px;-fx-background-color: #90caf9; -fx-text-fill: white;");
        return button;
    }

    // Helper method to show an alert
    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setHeaderText(message);
        alert.showAndWait();
}
}