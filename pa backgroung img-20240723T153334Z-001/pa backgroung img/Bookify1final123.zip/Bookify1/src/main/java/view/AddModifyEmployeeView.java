package view;

import controller.EmployeeController;
import javafx.scene.control.*;
import model.Employee;

import java.time.LocalDate;
import java.util.concurrent.atomic.AtomicReference;

public class AddModifyEmployeeView {

    private TextField name;
    private TextField surname ;
    private TextField username ;
    private TextField password ;
    private TextField phone ;
    private TextField email ;
    private DatePicker birthdayPicker;
    private RadioButton male ;
    private RadioButton female ;
    private RadioButton other ;
    private RadioButton LibrarianButton ;
    private RadioButton ManagerButton ;
    private RadioButton AdministratorButton ;
    private TextField salary;
    private RadioButton newBill ;
    private RadioButton searchTheStore ;
    private RadioButton billHistory ;
    private RadioButton supplyTheStore ;
    private RadioButton lowStock ;
    private RadioButton Lperformance ;
    private RadioButton statistics ;







    AddModifyEmployeeView(){

    }

    public AddModifyEmployeeView(TextField name, TextField surname, TextField username,TextField password,TextField phone,TextField email,TextField salary,DatePicker birthdayPicker,RadioButton male,RadioButton female,RadioButton other,RadioButton LibrarianButton,RadioButton ManagerButton,RadioButton
            AdministratorButton,RadioButton newBill,RadioButton searchTheStore,RadioButton billHistory,RadioButton supplyTheStore,RadioButton lowStock,RadioButton Lperformance,RadioButton statistics) {
        this.name  = name;
        this.surname  = surname;
        this.username  = username;
        this.password  = password;
        this.phone  = phone;
        this.email= email;
        this.birthdayPicker  = birthdayPicker;
        this.male  = male;
        this.female  = female;
        this.other=other;
        this.LibrarianButton=LibrarianButton;
        this.ManagerButton=ManagerButton;
        this.AdministratorButton=AdministratorButton;
        this.salary=salary;
        this.newBill=newBill;
        this.searchTheStore=searchTheStore;
        this.billHistory=billHistory;
        this.supplyTheStore=supplyTheStore;
        this.lowStock=lowStock;
        this.Lperformance=Lperformance;
        this.statistics=statistics;
    }



    public void setFields(Employee employee) {
        name.setText(employee.getFirstName());

        surname.setText(employee.getLastName());
        username.setText(employee.getUsername());
        password.setText(employee.getPassword());
        phone.setText(String.valueOf(employee.getPhone()));
        email.setText(employee.getEmail());
        salary.setText(String.valueOf(employee.getSalary()));
        birthdayPicker.setValue((employee.getBirthday()));
        if ("Male".equals(employee.getGenre())) {
            male.setSelected(true);
        } else if ("Female".equals(employee.getGenre())) {
            female.setSelected(true);
        } else {
            other.setSelected(true);
        }

        if (employee.getRole() .equals(LibrarianButton.getText())) {
            LibrarianButton.setSelected(true);
        } else if (employee.getRole() .equals(ManagerButton.getText())) {
            ManagerButton.setSelected(true);
        } else if (employee.getRole() .equals(AdministratorButton.getText())) {
            AdministratorButton.setSelected(true);
        }



    }

    public void clearFields() {
        name.clear();
        surname.clear();
        username.clear();
        password.clear();
        phone.clear();
        email.clear();
        salary.clear();
    }

    public Employee getEmployeeInput() {
        String firstName1 = name.getText();
        String lastName1 = surname .getText();
        String username1 = username.getText();
        String passwordField1 = password.getText();
        String gender1 = "";
        String role1;
        int position;
        double salary1=Double.parseDouble(salary.getText());

        int phone1=Integer.parseInt(phone.getText());
        LocalDate birthday1=birthdayPicker.getValue();


        String email1=email.getText();

        if (LibrarianButton.isSelected()) {

            role1 = LibrarianButton.getText();
        } else if (ManagerButton.isSelected()) {
            role1 = ManagerButton.getText();
        } else {
            role1 = AdministratorButton.getText();
        }

        if (male.isSelected()) {
            gender1 = male.getText();
        } else if (female.isSelected()) {
            gender1 = female.getText();
        } else {
            gender1 = other.getText();
        }



Employee a=new Employee(firstName1, lastName1, email1, passwordField1, gender1,role1,birthday1,phone1,username1,salary1);

        if(supplyTheStore.isSelected()){
            a.setNrsupply(1);
            System.out.println( a.getNrsupply());

        }
        if(lowStock.isSelected()){
            //  isgoingtochange.setNrlowstock(0);
            a.setNrlowstock(1);
        }
        if(statistics.isSelected()){
            a.setNrstatistics(1);
        }
        if(Lperformance.isSelected()){
            a.setNrlperformance(1);
        }
        if(newBill.isSelected()){
            a.setNrcreatebill(1);
        }
        if(searchTheStore.isSelected()){
            a.setNrsearchstore(1);
        }
        if(billHistory.isSelected()){
            a.setNrbillhistory(1);
        }
        return a;
    }
}

