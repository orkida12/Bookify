package view;
import controller.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import model.Book;
import model.Employee;
//import model.Librarian;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class LibrarianPerformance {
    public BookController bookController;
    public BillController billController;
    public EmployeeController employeeController;
    public Employee user;

    public LibrarianPerformance(BillController billController, BookController bookController, EmployeeController employeeController, Employee user) {
        this.billController = billController;
        this.bookController = bookController;
        this.employeeController = employeeController;
        this.user = user;
    }

    public Scene librarian_preformance_view(Stage satge, LibrarianController librarianController) {

        GridPane gridPane1 = new GridPane();
        gridPane1.setAlignment(Pos.CENTER);
        gridPane1.setPadding(new Insets(11.5, 11.5, 11.5, 11.5));
        gridPane1.setHgap(8);
        gridPane1.setVgap(5);

        //   Button get  = new Button("Get");
        Label label = new Label("Choose the date for checking  the performance of the librarians.");
        label.setStyle("-fx-font-size: 20px;"); // Set a larger font size

        gridPane1.add(label, 0, 1);
        Button certiandate = createStyledButton("Certain Date");

        Button periodtime = createStyledButton("Period of time ");
        Button back = createStyledButton("Back");
      back.setOnAction(e->{

          if(user.getNr()==0) {
              AdministratorHomePageView hv2 = new AdministratorHomePageView(billController,bookController,employeeController,user);
              satge.setTitle("AdministratorHomePageView");

              satge.setScene(hv2.showView(satge));
              System.out.println("0");
          }
          else if (user.getNr()==1){
              ManagerHomePageView homePageView=new ManagerHomePageView(billController,bookController,employeeController,user);
              satge.setTitle("ManagerHomePage");
              satge.setScene(homePageView.showView(satge));
          }else{
              LibrarianHomePageView homePageView=new LibrarianHomePageView(billController,bookController,employeeController,user);
              satge.setTitle("LibrarianHomePageView");
              satge.setScene(homePageView.showView(satge));
          }
      });
        HBox hBox = new HBox();
        hBox.getChildren().addAll(certiandate, periodtime,back);
        hBox.setSpacing(5);
        gridPane1.add(hBox, 0, 2);
        Image backgroundImage = new Image("Photo/Fotohomepage1.jpg");

        // Create a background image
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);

        // Set the background image to the grid pane
        gridPane1.setBackground(new Background(background));

        Scene scene = new Scene(gridPane1, 1079, 771);

        certiandate.setOnAction(e -> {
            CertainDateView certainDateView = new CertainDateView(billController, bookController, employeeController, user);
            satge.setScene(certainDateView.ShowCertainDate(satge,librarianController));
        });
        periodtime.setOnAction(e->{
            PeriodDateView periodDateView=new PeriodDateView(billController,bookController,employeeController,user);
            satge.setScene(periodDateView.showView(satge,librarianController));

        });

        return scene;

    }

    private Button createStyledButton(String text) {
        Button button = new Button(text);
        button.setStyle("-fx-font-size: 20px;-fx-background-color: #90caf9; -fx-text-fill: white;");
        return button;
}

}