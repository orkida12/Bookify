package view;

import javafx.scene.control.ListView;
import model.Employee;

import java.util.List;

public class EmployeeListView {
    private ListView<String> listView;

    public EmployeeListView(ListView<String> listView) {
        this.listView = listView;
    }

    public void displayEmployees(List<Employee> employees) {
        for (Employee employee : employees) {
            listView.getItems().add(employee.getUsername() + " - " + employee.getRole());
        }
    }

    public void clearList() {
        listView.getItems().clear();
    }

    public ListView<String> getListView() {
        return listView;
    }
}
