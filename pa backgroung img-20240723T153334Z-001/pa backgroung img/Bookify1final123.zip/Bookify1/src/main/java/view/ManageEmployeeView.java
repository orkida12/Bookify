package view;

import controller.AdministratorController;
import controller.BillController;
import controller.BookController;
import controller.EmployeeController;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import model.Employee;

public class ManageEmployeeView {

    private Employee currentUser;
    private BookController bookController;
    private BillController billController;
    private EmployeeController employeeController;


    public ManageEmployeeView()
    {}
    public ManageEmployeeView(BillController billController, BookController bookController, EmployeeController employeeController, Employee currentUser){
        this.currentUser=currentUser;
        this.billController=billController;
        this.bookController=bookController;
        this.employeeController=employeeController;


    }
    public Scene showView(Stage stage) {
        BorderPane borderPane = new BorderPane();
        borderPane.setPadding(new Insets(10));

        // Employee Details on the Left
        VBox employeeDetails = new VBox(10);
        TextField name = createTextFieldWithPrompt("Name");
        TextField surname = createTextFieldWithPrompt("Surname");
        TextField username = createTextFieldWithPrompt("Username");
        TextField password = createTextFieldWithPrompt("Password");
        TextField phone = createTextFieldWithPrompt("Phone");
        TextField email = createTextFieldWithPrompt("Email");
        TextField salary= createTextFieldWithPrompt("Salary");
        DatePicker birthdayPicker = new DatePicker();

        //  Gender Toggle
        ToggleGroup genderToggleGroup = new ToggleGroup();
        RadioButton male = new RadioButton("Male");
        male.setToggleGroup(genderToggleGroup);
        RadioButton female = new RadioButton("Female");
        female.setToggleGroup(genderToggleGroup);
        RadioButton other = new RadioButton("Other");
        other.setToggleGroup(genderToggleGroup);

        ToggleGroup roleToggleGroup = new ToggleGroup();
        RadioButton LibrarianButton = new RadioButton("Librarian");
        LibrarianButton.setToggleGroup(roleToggleGroup);
        RadioButton ManagerButton = new RadioButton("Manager");
        ManagerButton.setToggleGroup(roleToggleGroup);
        RadioButton AdministratorButton = new RadioButton("Administrator");
        AdministratorButton.setToggleGroup(roleToggleGroup);

        RadioButton newBill=new RadioButton("newBill");
        RadioButton searchTheStore=new RadioButton("searchTheStore");

        RadioButton billHistory=new RadioButton("billHistory");



        RadioButton supplyTheStore=new RadioButton("supplyTheStore");
        RadioButton lowStock=new RadioButton("lowStock");

        RadioButton Lperformance=new RadioButton("Lperformance");
        RadioButton statistics=new RadioButton("statistics");



        employeeDetails.getChildren().addAll(name, surname, username, password, phone, email,salary, birthdayPicker);
        HBox employeehbox = new HBox();
        employeehbox.setSpacing(20);

        // Gender VBox
        VBox genderBox = new VBox();
        genderBox.setAlignment(Pos.CENTER_LEFT);
        genderBox.setSpacing(5);

        Label genderLabel = new Label("Gender");
        Label genderSeparator = new Label("-----------");


        genderBox.getChildren().addAll(genderLabel, genderSeparator, male, female, other);

        // Role VBox
        VBox roleBox = new VBox();
        roleBox.setAlignment(Pos.CENTER_LEFT);
        roleBox.setSpacing(5);

        Label roleLabel = new Label("Role");
        Label roleSeparator = new Label("-----------");


        roleBox.getChildren().addAll(roleLabel, roleSeparator, LibrarianButton, ManagerButton, AdministratorButton);

        // Add both VBox containers to the HBox
        employeehbox.getChildren().addAll(genderBox, roleBox);




        employeeDetails.getChildren().add(employeehbox);
        employeeDetails.getChildren().addAll(new Label("Librarian"),new Label("-----------"),newBill,searchTheStore,billHistory);

        employeeDetails.getChildren().addAll(new Label("Manager"),new Label("-----------"),supplyTheStore,lowStock,Lperformance,statistics);


// Add a listener to roleToggleGroup to handle role selection
        roleToggleGroup.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
            @Override
            public void changed(ObservableValue<? extends Toggle> observable, Toggle oldValue, Toggle newValue) {
                if (newValue == LibrarianButton) {
                    // If Librarian is selected, enable librarian role radio buttons
                    enableLibrarianRoleButtons(false);
                } else {
                    // If other roles are selected, disable librarian role radio buttons
                    enableLibrarianRoleButtons(true);
                }

                if (newValue == ManagerButton) {
                    // If Librarian is selected, enable librarian role radio buttons
                    enableManagerRoleButtons(false);
                } else {
                    // If other roles are selected, disable librarian role radio buttons
                    enableManagerRoleButtons(true);
                }

            }

            private void enableLibrarianRoleButtons(boolean b) {
                    newBill.setDisable(!b);
                    searchTheStore.setDisable(!b);
                    billHistory.setDisable(!b);

                }
            private void enableManagerRoleButtons(boolean b) {
                supplyTheStore.setDisable(!b);
                lowStock.setDisable(!b);
                Lperformance.setDisable(!b);
                statistics.setDisable(!b);

            }
        });



        // Employee List in the Center
        ListView<String> employeeListView = new ListView<>();
        EmployeeListView listView = new EmployeeListView(employeeListView);

        // Buttons at the Bottom
        HBox buttonsBox = new HBox(10);
        buttonsBox.setSpacing(10);
        buttonsBox.setAlignment(Pos.CENTER);
        Button addButton = createStyledButton("Add Employee");
        Button removeButton = createStyledButton("Remove Employee");
        Button manageButton = createStyledButton("Manage Employee");
        Button back = createStyledButton("Back");
        addButton.setMinSize(150, 50); // Set a fixed size for all buttons
        removeButton.setMinSize(150, 50); // Set a fixed size for all buttons
        manageButton.setMinSize(150, 50); // Set a fixed size for all buttons
        back.setMinSize(150, 50); // Set a fixed size for all buttons



        buttonsBox.getChildren().addAll(addButton, removeButton, manageButton, back);

        name.textProperty().addListener((observable, oldValue, newValue) -> validateName(newValue));
        surname.textProperty().addListener((observable, oldValue, newValue) -> validateSurname(newValue));
        phone.textProperty().addListener((observable, oldValue, newValue) -> validatePhone(newValue));


        // Set BorderPane regions
        borderPane.setLeft(employeeDetails);
        borderPane.setCenter(employeeListView);
        borderPane.setBottom(buttonsBox);

        // Event handling

        AddModifyEmployeeView formView = new AddModifyEmployeeView(name, surname, username, password, phone, email,salary, birthdayPicker ,male, female, other, LibrarianButton, ManagerButton, AdministratorButton, newBill, searchTheStore, billHistory, supplyTheStore, lowStock, Lperformance, statistics);
        AdministratorController controller = new AdministratorController(employeeController, listView, formView);

        controller.showEmployeeList();

        addButton.setOnAction(e ->{controller.addEmployee();

            employeeController.writeEmployee();
        });

        removeButton.setOnAction(e -> {
            String selectedEmployee = employeeListView.getSelectionModel().getSelectedItem();
            if (selectedEmployee != null) {
                String[] parts = selectedEmployee.split(" - ");
                String employeeName = parts[0];
                Employee employeeToRemove = employeeController.getEmployees().stream()
                        .filter(employee -> employee.getUsername().equals(employeeName))
                        .findFirst().orElse(null);
                if (employeeToRemove != null) {
                    controller.removeEmployee(employeeToRemove);
                    employeeController.writeEmployee();

                }
            }
        });

        manageButton.setOnAction(e -> {
            String selectedEmployee = employeeListView.getSelectionModel().getSelectedItem();
            if (selectedEmployee != null) {
                String[] parts = selectedEmployee.split(" - ");
                String employeeName = parts[0];
                Employee employeeToManage = employeeController.getEmployees().stream()
                        .filter(employee -> employee.getUsername().equals(employeeName))
                        .findFirst().orElse(null);

                if (employeeToManage != null) {

                    formView.setFields(employeeToManage);
                    Employee modifiedEmployee = formView.getEmployeeInput();
                    if (modifiedEmployee != null) {
                        employeeController.modifyEmployee(employeeToManage, modifiedEmployee);
                        controller.modifyEmployee(employeeToManage,modifiedEmployee);
                        formView.setFields(modifiedEmployee);

                            controller.showEmployeeList();

                    }
                    employeeController.writeEmployee();
                }
            }

        });




        back.setOnAction(e -> {
            AdministratorHomePageView sv = new AdministratorHomePageView(billController,bookController,employeeController,currentUser);
            stage.setScene(sv.showView(stage));});

        Image backgroundImage = new Image("Photo/Fotohomepage1.jpg");

        // Create a background image
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);

        // Set the background image to the grid pane
        borderPane.setBackground(new Background(background));

        return new Scene(borderPane, 1079, 771);
    }

    //  Gives Blue Color to the Buttons
    private Button createStyledButton(String text) {
        Button button = new Button(text);
        button.setStyle("-fx-background-color: #90caf9; -fx-text-fill: white;");
        return button;
    }

    //  Makes the field Word Disappear
    private TextField createTextFieldWithPrompt(String prompt) {
        TextField textField = new TextField();
        textField.setPromptText(prompt);

        textField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.isEmpty()) {
                textField.setPromptText("");
            } else {
                textField.setPromptText(prompt);
            }
        });

        return textField;
    }

    // Validation methods for Labels
    private void validateName(String name) {
        if (!name.matches("[a-zA-Z]*")) {
            showAlert("Invalid Name", "Name should contain only letters.");
        }
    }

    private void validateSurname(String surname) {
        if (!surname.matches("[a-zA-Z]*")) {
            showAlert("Invalid Surname", "Surname should contain only letters.");
        }
    }

    private void validatePhone(String phone) {
        if (!phone.matches("\\d*")) {
            showAlert("Invalid Phone", "Phone should contain only numbers.");
        }
    }

    // Alerts when Validation is wrong
    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }


}