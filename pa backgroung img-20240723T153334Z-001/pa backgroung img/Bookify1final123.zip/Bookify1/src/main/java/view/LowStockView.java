package view;

import controller.BillController;
import controller.BookController;
import controller.EmployeeController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import model.Employee;

public class LowStockView {
    private Employee currentUser;
    private BookController bookController;
    private BillController billController;
    private EmployeeController employeeController;

    public LowStockView(BillController billController, BookController bookController, EmployeeController employeeController, Employee currentUser) {
        this.currentUser = currentUser;
        this.billController = billController;
        this.bookController = bookController;
        this.employeeController = employeeController;
    }

    public Scene lowStock(Stage stage) {
        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setPadding(new Insets(20));
        gridPane.setHgap(10);
        gridPane.setVgap(15);

        gridPane.add(createHeaderLabel("ISBN"), 0, 0);
        gridPane.add(createHeaderLabel("Title"), 1, 0);
        gridPane.add(createHeaderLabel("Author"), 2, 0);
        gridPane.add(createHeaderLabel("Stock"), 3, 0);

        int row = 1;
        for (int i = 0; i < bookController.getBook_arraylist().size(); i++) {
            if (bookController.check_stock(i)) {
                gridPane.add(createLabel(bookController.getIsbn(i)), 0, row);
                gridPane.add(createLabel(bookController.getTitle(i)), 1, row);
                gridPane.add(createLabel(bookController.getAuthor(i)), 2, row);
                gridPane.add(createLabel(Integer.toString(bookController.getStock(i))), 3, row);
                row++;
            }
        }

        Button back = createStyledButton("Back");

        gridPane.add(back, 0, row, 4, 1);

        back.setOnAction(e -> {
            if (currentUser.getNr() == 0) {
                AdministratorHomePageView hv2 = new AdministratorHomePageView(billController, bookController, employeeController, currentUser);
                stage.setTitle("AdministratorHomePageView");
                stage.setScene(hv2.showView(stage));
            } else if (currentUser.getNr() == 1) {
                ManagerHomePageView homePageView = new ManagerHomePageView(billController, bookController, employeeController, currentUser);
                stage.setTitle("ManagerHomePage");
                stage.setScene(homePageView.showView(stage));
            } else {
                LibrarianHomePageView homePageView = new LibrarianHomePageView(billController, bookController, employeeController, currentUser);
                stage.setTitle("LibrarianHomePageView");
                stage.setScene(homePageView.showView(stage));
            }
        });
        Image backgroundImage = new Image("Photo/Fotohomepage1.jpg");

        // Create a background image
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);

        // Set the background image to the grid pane
        gridPane.setBackground(new Background(background));
        Scene scene = new Scene(gridPane, 1079, 771);
        return scene;
    }

    private Label createHeaderLabel(String text) {
        Label label = new Label(text);
        label.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");


        return label;
    }

    private Label createLabel(String text) {
        Label l1=new Label(text);
        l1.setStyle("-fx-font-size: 20px;");

        return l1;
    }

    private Button createStyledButton(String text) {
        Button button = new Button(text);
        button.setStyle("-fx-font-size: 20px;-fx-background-color: #90caf9; -fx-text-fill: white;");
        return button;
}
}