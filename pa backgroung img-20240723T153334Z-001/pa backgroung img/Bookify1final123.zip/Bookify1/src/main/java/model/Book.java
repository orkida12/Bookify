package model;

import java.io.Serializable;
import java.util.Date;


public class Book implements Serializable {
    private static final long serialVersionUID = 1L;

    private String ISBN;
    private String title;
    private String category;
    private String supplier;
    private Date purchaseDate;
    private double purchasePrice;
    private double sellingPrice;
    private String author;
    private int stock;
    private int cnt_mostSold;
    public static  int TotalBookBought;
    public int getCnt() {
        return cnt_mostSold;
    }

    public void setCnt(int cnt) {
        this.cnt_mostSold = cnt;
    }

    // Constructors
    public Book(){

    }
    public Book(String ISBN, String title, String category, String supplier,
                double purchasePrice, double sellingPrice, String author, int stock) {
        this.ISBN = ISBN;
        this.title = title;
        this.category = category;
        this.supplier = supplier;
        this.purchaseDate = new Date();
        this.purchasePrice = purchasePrice;
        this.sellingPrice = sellingPrice;
        this.author = author;
        this.stock = stock;
        this.cnt_mostSold=0;


    }
    public static int getTotalBookBought() {
        return TotalBookBought;
    }

    public static void setTotalBookBought(int totalBookBought) {
        TotalBookBought = totalBookBought;
    }




    public String getISBN() {
        return ISBN;
    }

    public String getTitle() {
        return title;
    }

    public String getCategory() {
        return category;
    }

    public String getSupplier() {
        return supplier;
    }

    public Date getPurchaseDate() {
        return purchaseDate;
    }

    public double getPurchasePrice() {
        return purchasePrice;
    }



    public double getSellingPrice() {
        return sellingPrice;
    }

    public String getAuthor() {
        return author;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

// Additional methods as needed, e.g., save/update book data

    @Override
    public String toString() {
        return "Book{" +
                "ISBN='" + ISBN + '\'' +
                ", title='" + title + '\'' +
                ", category='" + category + '\'' +
                ", supplier='" + supplier + '\'' +
                ", purchaseDate='" + purchaseDate + '\'' +
                ", purchasePrice=" + purchasePrice +
                ", sellingPrice=" + sellingPrice +
                ", author='" + author + '\'' +
                ", stock=" + stock + '\'' +
                '}';
    }
}
