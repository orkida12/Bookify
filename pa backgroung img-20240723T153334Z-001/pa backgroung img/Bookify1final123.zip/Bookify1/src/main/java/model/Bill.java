package model;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import  java.util.Date;
import controller.BookController;


public class Bill implements Serializable {
    private static final long serialVersionUID = -3292385108400454436L;

    private Date bil_date;
    private int nr_items;
    private static int bill_nr;
    private int realBillNr;
    private String[] author;
    private String[] title;
    private String lib_username;
    private double total_price;
    private double[] single_price;
    private String[] ISBN;
    private int[] quantity;
    private Book book;
    private static int total_book_sold;
    public Bill(){

    }
    public Bill(int nr_items, String[] ISBN,int [] quantity, BookController bookController, Employee  librarianController) {
        this.nr_items=nr_items;
        this.bil_date = new Date();
        bill_nr+=1;
        this.realBillNr=bill_nr;
        this.ISBN = new String[nr_items];
        this.author = new String[nr_items];
        this.quantity = new int[nr_items];
        this.title = new String[nr_items];
        this.single_price=new double[nr_items];
        this.lib_username=librarianController.getUsername();

        for (int i = 0; i < nr_items; i++) {
            this.book=bookController.serchIsbn(ISBN[i]);
            this.ISBN[i] =book.getISBN();
            this.title[i]=book.getTitle();
            this.author[i]=book.getAuthor();
            this.quantity[i]=quantity[i];
            this.book.setStock(this.book.getStock()-this.quantity[i]);
            this.single_price[i]=book.getSellingPrice()*this.quantity[i];
            this.total_price+=this.single_price[i];
            bookController.setcnt(this.quantity[i],ISBN[i]);

        }

    }

    public static int getTotal_book_sold() {
        return total_book_sold;
    }

    public static void setTotal_book_sold(int total_book_sold) {
        Bill.total_book_sold = total_book_sold;
    }

    public static int getBill_nr() {
        return bill_nr;
    }

    public Book getBook() {
        return book;
    }

    public void setBook(Book book) {
        this.book = book;
    }

    public Date getBil_date() {
        return bil_date;
    }

    public double getTotal_price() {
        return total_price;
    }

    public double[] getSingle_price() {
        return single_price;
    }

    public int getNr_items() {
        return nr_items;
    }

    public int[] getQuantity() {
        return quantity;
    }

    public String getLib_username() {
        return lib_username;
    }

    public String[] getAuthor() {
        return author;
    }

    public String[] getISBN() {
        return ISBN;
    }

    public String[] getTitle() {
        return title;
    }

    public void setAuthor(String[] author) {
        this.author = author;
    }

    public void setBil_date(Date bil_date) {
        this.bil_date = bil_date;
    }

    public void setISBN(String[] ISBN) {
        this.ISBN = ISBN;
    }

    public void setLib_username(String lib_username) {
        this.lib_username = lib_username;
    }

    public void setNr_items(int nr_items) {
        this.nr_items = nr_items;
    }

    public void setQuantity(int[] quantity) {
        this.quantity = quantity;
    }

    public void setSingle_price(double[] single_price) {
        this.single_price = single_price;
    }

    public void setTotal_price(double total_price) {
        this.total_price = total_price;
    }

    public void setTitle(String[] title) {
        this.title = title;
    }
    public void printBill() {
        System.out.println("Date: " + this.bil_date+" Nr ="+realBillNr);

        for (int i = 0; i < nr_items; i++) {
            System.out.println(
                    "Title = " + title[i] + ", " +
                            "Quantity = " + quantity[i] + ", " +
                            "Price = " + single_price[i]+", "
            );


        }

        System.out.println("Total Price = " + total_price);
    }
    public void writeToBill() {
        String filepath = "Bills/Bill nr" + realBillNr + ".txt";

        try (BufferedWriter filewrite = new BufferedWriter(new FileWriter(filepath))) {
            filewrite.write("Date: " + this.bil_date + " Nr =" + realBillNr);
            filewrite.newLine();

            filewrite.write("--------------------");

            filewrite.newLine();

            for (int i = 0; i < nr_items; i++) {
                filewrite.write("Title: " + title[i]);
                filewrite.newLine();
                filewrite.write("Quantity: " + quantity[i]);
                filewrite.newLine();
                filewrite.write("Price: " + single_price[i]);
                filewrite.newLine();
                filewrite.write("--------------------");
                filewrite.newLine();
            }

            filewrite.write("Total Price = " + total_price);

        } catch (IOException e) {
            // Handle IOException
            e.printStackTrace();
}
    }
}