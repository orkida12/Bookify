module com.example.bookify1 {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.dlsc.formsfx;

    opens com.example.bookify1 to javafx.fxml;
    exports com.example.bookify1;
}