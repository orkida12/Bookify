package view;

import controller.BillController;
import controller.BookController;
import controller.EmployeeController;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import model.Employee;

public class AccessView {
        private Employee currentUser;
        private BookController bookController;
        private BillController billController;
        private EmployeeController employeeController;
        private SupplyTheStoreView supplyTheStoreView;

        public AccessView(BillController billController, BookController bookController, EmployeeController employeeController, Employee currentUser) {
                this.currentUser = currentUser;
                this.billController = billController;
                this.bookController = bookController;
                this.employeeController = employeeController;
                supplyTheStoreView = new SupplyTheStoreView(this.billController, this.bookController, this.employeeController, this.currentUser);
        }

        public Scene showScene(Stage stage) {
                GridPane grid = new GridPane();
                grid.setHgap(10);
                grid.setVgap(10);
                grid.setPadding(new Insets(20, 20, 20, 20));

                Label searchlabel = new Label("Search the username");
                TextField searchfield = createTextFieldWithPrompt("Username");
                Button search = createStyledButton("Search");

                grid.add(searchlabel, 0, 0);
                grid.add(searchfield, 1, 0);
                grid.add(search, 2, 0);

                ToggleGroup librarianToggleGroup = new ToggleGroup();
                RadioButton newBill = new RadioButton("New Bill");
                newBill.setToggleGroup(librarianToggleGroup);
                RadioButton searchTheStore = new RadioButton("Search the Store");
                searchTheStore.setToggleGroup(librarianToggleGroup);
                RadioButton billHistory = new RadioButton("Bill History");
                billHistory.setToggleGroup(librarianToggleGroup);

                ToggleGroup managerToggleGroup = new ToggleGroup();
                RadioButton supplyTheStore = new RadioButton("Supply the Store");
                supplyTheStore.setToggleGroup(managerToggleGroup);
                RadioButton lowStock = new RadioButton("Low Stock");
                lowStock.setToggleGroup(managerToggleGroup);
                RadioButton Lperformance = new RadioButton("Performance");
                Lperformance.setToggleGroup(managerToggleGroup);
                RadioButton statistics = new RadioButton("Statistics");
                statistics.setToggleGroup(managerToggleGroup);

                grid.add(new Label("Manager"), 3, 1);
                grid.add(supplyTheStore, 3, 2);
                grid.add(lowStock, 3, 3);
                grid.add(Lperformance, 3, 4);
                grid.add(statistics, 3, 5);

                grid.add(new Label("Librarian"), 1, 1);
                grid.add(newBill, 1, 2);
                grid.add(searchTheStore, 1, 3);
                grid.add(billHistory, 1, 4);

                Button backButton = createStyledButton("Back");
                backButton.setOnAction(e -> {
                        AdministratorHomePageView administratorHomePageView = new AdministratorHomePageView(billController, bookController, employeeController, currentUser);
                        stage.setScene(administratorHomePageView.showView(stage));
                });

                HBox bottomBox = new HBox(10);
                bottomBox.getChildren().addAll(backButton);
                bottomBox.setPadding(new Insets(20, 0, 0, 0));
                bottomBox.setAlignment(javafx.geometry.Pos.CENTER);

                grid.add(bottomBox, 0, 6, 3, 1);

                Scene scene = new Scene(grid, 700, 500);
                return scene;
        }

        private TextField createTextFieldWithPrompt(String prompt) {
                TextField textField = new TextField();
                textField.setPromptText(prompt);

                // Add a listener to hide the prompt text when the user starts typing
                textField.textProperty().addListener((observable, oldValue, newValue) -> {
                        if (!newValue.isEmpty()) {
                                textField.setPromptText("");
                        } else {
                                textField.setPromptText(prompt);
                        }
                });

                return textField;
        }

        private Button createStyledButton(String text) {
                Button button = new Button(text);
                button.setStyle("-fx-background-color: #90caf9; -fx-text-fill: white;");
                return button;
}
}