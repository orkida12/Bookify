package view;

import controller.BillController;
import controller.BookController;
import controller.EmployeeController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import model.Book;
import model.Employee;

public class SearchTheStore {
    private Employee currentUser;
    private BookController bookController;
    private BillController billController;
    private EmployeeController employeeController;

    public SearchTheStore(BillController billController, BookController bookController, EmployeeController employeeController, Employee currentUser) {
        this.currentUser = currentUser;
        this.billController = billController;
        this.bookController = bookController;
        this.employeeController = employeeController;


    }

    public Scene viewSupply(Stage stage) {
        GridPane gridPane1 = new GridPane();
        gridPane1.setAlignment(Pos.CENTER);
        gridPane1.setPadding(new Insets(11.5, 11.5, 11.5, 11.5));
        gridPane1.setHgap(8);
        gridPane1.setVgap(5);

        Button search = createStyledButton("Search");
        Button back = createStyledButton("Back");
        TextField ISBN = createTextFieldWithPrompt("ISBN");
        Label l1=new Label("Enter the ISBN");
        l1.setStyle("-fx-font-size: 20px;"); // Set button color and text color

        gridPane1.add(l1, 0, 0);
        gridPane1.add(ISBN, 1, 0);
        gridPane1.add(search, 2, 0);
        gridPane1.add(back, 2, 2);
        search.setOnAction(e->{
            String ISBN1 = ISBN.getText();
            Book book=bookController.serchIsbn(ISBN1);
            if (book==null){
                Alert alert=new Alert(Alert.AlertType.INFORMATION);
                alert.setHeaderText("Book not found");
                alert.showAndWait();
            }
            else if(book.getISBN().equals(ISBN1)){
                int index=BookController.getIndex();
                ShowBookView showBookView=new ShowBookView(billController,bookController,employeeController,currentUser);
                stage.setScene(showBookView.viewSupply(stage ,ISBN1,index));


            }

        });
        back.setOnAction(e -> {

                    if(currentUser.getNr()==0) {
                        AdministratorHomePageView hv2 = new AdministratorHomePageView(billController,bookController,employeeController,currentUser);
                        stage.setTitle("AdministratorHomePageView");

                        stage.setScene(hv2.showView(stage));
                        System.out.println("0");
                    }
                    else if (currentUser.getNr()==1){
                        ManagerHomePageView homePageView=new ManagerHomePageView(billController,bookController,employeeController,currentUser);
                        stage.setTitle("ManagerHomePage");
                        stage.setScene(homePageView.showView(stage));
                    }else{
                        LibrarianHomePageView homePageView=new LibrarianHomePageView(billController,bookController,employeeController,currentUser);
                        stage.setTitle("LibrarianHomePageView");
                        stage.setScene(homePageView.showView(stage));
                    }
                    System.out.println("898");
        }

        );
        Image backgroundImage = new Image("Photo/Fotohomepage1.jpg");

        // Create a background image
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);

        // Set the background image to the grid pane
        gridPane1.setBackground(new Background(background));
        Scene scene = new Scene(gridPane1, 1079, 771);

        return scene;
    }

    private Button createStyledButton(String text) {
        Button button = new Button(text);
        button.setStyle("-fx-font-size: 20px;-fx-background-color: #90caf9; -fx-text-fill: white;"); // Set button color and text color
        return button;
    }

    private TextField createTextFieldWithPrompt(String prompt) {
        TextField textField = new TextField();
        textField.setStyle("-fx-font-size: 20px;"); // Set button color and text color

        textField.setPromptText(prompt);

        // Add a listener to hide the prompt text when the user starts typing
        textField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.isEmpty()) {
                textField.setPromptText("");
            } else {
                textField.setPromptText(prompt);
            }
        });

        return textField;
    }
}