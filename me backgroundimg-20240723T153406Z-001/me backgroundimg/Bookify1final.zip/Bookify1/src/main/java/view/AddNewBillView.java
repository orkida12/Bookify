package view;

import controller.BillController;
import controller.BookController;
import controller.EmployeeController;
import javafx.application.Application;
import javafx.beans.binding.BooleanBinding;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import model.Employee;


public class AddNewBillView {
    private BillController billController;
    private BookController bookController;
    private EmployeeController employeeController;
    private Employee currentUser;
    private String UserName;
    private int index;

    public AddNewBillView(BillController billController, BookController bookController, EmployeeController employeeController, Employee currentUser) {
        this.billController = billController;
        this.bookController = bookController;
        this.currentUser = currentUser;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public Scene showAddBill(Stage stage, int nr_ofItems){
        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setPadding(new Insets(25, 25, 25, 25));

        // Label and TextField for ISBN
        Label isbnLabel = new Label("Enter ISBN:");
        gridPane.add(isbnLabel, 0, 0);
        isbnLabel.setStyle("-fx-font-size: 20px;"); // Set button color and text color


        TextField ISBN = createTextFieldWithPrompt("ISBN");
        gridPane.add(ISBN, 1, 0);

        // Label and TextField for Quantity
        Label quantityLabel = new Label("Enter Quantity:");
        quantityLabel.setStyle("-fx-font-size: 20px;"); // Set button color and text color

        gridPane.add(quantityLabel, 0, 1);

        TextField quantity = createTextFieldWithPrompt("Quantity");
        quantity.setStyle("-fx-font-size: 20px;"); // Set button color and text color

        gridPane.add(quantity, 1, 1);

        // Button
        Button addButton = createStyledButton("Add");

        gridPane.add(addButton, 1, 2);
        Button backButton = createStyledButton("Back");
        gridPane.add(backButton, 1, 3);

        // Disable the "Add" button initially
        addButton.setDisable(true);


        // Binding to enable/disable the "Add" button based on the TextField values
        BooleanBinding isISBNEmpty = ISBN.textProperty().isEmpty();
        BooleanBinding isQuantityEmpty = quantity.textProperty().isEmpty();
        addButton.disableProperty().bind(isISBNEmpty.or(isQuantityEmpty));

        // Validation for quantity
        quantity.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.isEmpty()) {
                validateQuantity(newValue);
            }
        });



        addButton.setOnAction(e -> {

            String Isbn = ISBN.getText();

            int q = Integer.parseInt(quantity.getText());
            billController.cretearray(Isbn, q,getIndex());
            setIndex((getIndex()+1));
            System.out.println(billController.getISbn());
            System.out.println(billController.getQuatity());
            System.out.println("dsfhhjdsfhds");
            System.out.println(Isbn);
            if(getIndex()==nr_ofItems){
                BillAddButtonView billAddButtonView=new BillAddButtonView(billController,bookController,employeeController,currentUser);
                stage.setScene(billAddButtonView.showView(stage,nr_ofItems));
            }


        });


        Image backgroundImage = new Image("Photo/Fotohomepage1.jpg");

        // Create a background image
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);

        // Set the background image to the grid pane
        gridPane.setBackground(new Background(background));

        // Set up the Scene
        Scene scene = new Scene(gridPane, 1079, 771);
        return scene;
    }

    private TextField createTextFieldWithPrompt(String prompt) {
        TextField textField = new TextField();
        textField.setStyle("-fx-font-size: 20px;"); // Set button color and text color

        textField.setPromptText(prompt);

        // Add a listener to hide the prompt text when the user starts typing
        textField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.isEmpty()) {
                textField.setPromptText("");
            } else {
                textField.setPromptText(prompt);
            }
        });

        return textField;
    }

    private Button createStyledButton(String text) {
        Button button = new Button(text);
        button.setStyle("-fx-font-size: 20px;-fx-background-color: #90caf9; -fx-text-fill: white;"); // Set button color and text color
        return button;
    }

    private void validateQuantity(String quantity) {
        if (!quantity.matches("\\d*")) {
            showAlert("Invalid Quantity", "Quantity should contain only numbers.");
        }
    }



    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}