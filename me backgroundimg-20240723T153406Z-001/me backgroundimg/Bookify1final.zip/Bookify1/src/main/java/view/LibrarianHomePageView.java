package view;

import controller.BillController;
import controller.BookController;
import controller.EmployeeController;
import controller.LibrarianController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import model.Employee;

public class LibrarianHomePageView {

    private Employee currentUser;
    private BookController bookController;
    private BillController billController;
    private EmployeeController employeeController;
    private SupplyTheStoreView supplyTheStoreView;
    private LibrarianController librarianController;


    public EmployeeController getEmployeeController() {
        return employeeController;
    }

    public LibrarianHomePageView(BillController billController, BookController bookController, EmployeeController employeeController, Employee currentUser){
        this.currentUser=currentUser;
        this.billController=billController;
        this.bookController=bookController;
        this.employeeController=employeeController;
        supplyTheStoreView = new SupplyTheStoreView(this.billController,this.bookController,this.employeeController,this.currentUser);
        this.librarianController=new LibrarianController(billController,bookController,employeeController,currentUser);


    }
    public Scene showView(Stage stage) {

        // Creating BorderPane
        BorderPane borderPane = new BorderPane();

        // Top - Welcome message
        BorderPane welcomePane = new BorderPane();
        welcomePane.setPadding(new Insets(10, 10, 10, 10));
        //shikoje si i doli suljonit kjo me username
        String welcomeText = "Welcome " + currentUser.getUsername()+"\u270C";
        Label welcomeLabel = new Label(welcomeText);
        welcomeLabel.setStyle("-fx-font-size: 70px;"); // Set a larger font size


        welcomePane.setCenter(welcomeLabel);
        borderPane.setTop(welcomePane);

        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setPadding(new Insets(20, 20, 20, 20));

        Button newBill = createStyledButton("CREATE NEW BILL");
        Button searchStore = createStyledButton("SEARCH THE STORE");
        Button billHistory = createStyledButton("BILL HISTORY");
        newBill.setMinSize(150, 50); // Set a fixed size for all buttons
        searchStore.setMinSize(150, 50); // Set a fixed size for all buttons
        billHistory.setMinSize(150, 50); // Set a fixed size for all buttons
        gridPane.add(newBill, 0, 1);
        gridPane.add(searchStore, 0, 2);
        gridPane.add(billHistory, 0, 3);




        Button supplyTheStore = createStyledButton("SUPPLY THE STORE");
        Button librarianPerformance = createStyledButton("CHECK L PERFORMANCE");
        Button lowStock = createStyledButton("LOW STOCK");
        Button statistics = createStyledButton("STATISTICS");

        supplyTheStore.setMinSize(150, 50); // Set a fixed size for all buttons
        librarianPerformance.setMinSize(150, 50); // Set a fixed size for all buttons
        lowStock.setMinSize(150, 50); // Set a fixed size for all buttons
        gridPane.add(supplyTheStore, 1, 1);
        gridPane.add(librarianPerformance, 1, 2);
        gridPane.add(lowStock, 1, 3);
        gridPane.add(statistics, 1, 4);
        borderPane.setCenter(gridPane);
        //SetonAction
        System.out.println(currentUser.getNrsupply());

            if (currentUser.getNrcreatebill() == 1) {
                //Te suljonit
                newBill.setOnAction(e -> {
                    AddItemsView LIB_enterNewBill = new AddItemsView(billController, bookController, employeeController, currentUser);
                    stage.setScene(LIB_enterNewBill.start(stage));
                });
            }
            if (currentUser.getNrsearchstore() == 1) {
                searchStore.setOnAction(e -> {
                    SearchTheStore sv = new SearchTheStore(billController, bookController, employeeController, currentUser);
                    stage.setScene(sv.viewSupply(stage));
                });
            }
            if (currentUser.getNrbillhistory() == 1) {
                billHistory.setOnAction(e -> {
                    BillHistoryView b = new BillHistoryView(billController, bookController, employeeController, currentUser);
                    stage.setScene(b.lowStock(stage));
                });
            }

            //Te orkides
            if (currentUser.getNrsupply() == 1) {
                supplyTheStore.setOnAction(e -> {
                    stage.setScene(this.supplyTheStoreView.viewSupply(stage));
                });
            }
        if (currentUser.getNrlperformance() == 1) {
            librarianPerformance.setOnAction(e -> {
                LibrarianPerformance ls = new LibrarianPerformance(billController, bookController, employeeController, currentUser);
                stage.setScene(ls.librarian_preformance_view(stage,librarianController));
            });
        }
            if (currentUser.getNrlowstock() == 1) {
                lowStock.setOnAction(e -> {
                    LowStockView ls = new LowStockView(billController, bookController, employeeController, currentUser);
                    stage.setScene(ls.lowStock(stage));
                });
            }
        if (currentUser.getNrstatistics() == 1) {
            statistics.setOnAction(e->{
                StatisticsView statisticsView=new StatisticsView(billController,bookController,employeeController,currentUser);
                stage.setScene(statisticsView.ShowStatistic(stage));
            });



        }

        Button signOutButton = createStyledButton("Sign Out");
        signOutButton.setMinSize(150, 50); // Set a fixed size for all buttons

        signOutButton.setOnAction(e -> {
            LogInView sv = new LogInView();
            stage.setScene(sv.showView(stage));
        });

        BorderPane bottomPane = new BorderPane();
        bottomPane.setPadding(new Insets(10, 10, 10, 10));
        bottomPane.setCenter(signOutButton);
        borderPane.setBottom(bottomPane);
        borderPane.setBottom(bottomPane);
        Image backgroundImage = new Image("Photo/Fotohomepage1.jpg");

        // Create a background image
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);

        // Set the background image to the grid pane
        borderPane.setBackground(new Background(background));
        Scene sc = new Scene(borderPane, 1079, 771);
        stage.setScene(sc);

        return sc;
    }

    private Button createStyledButton(String text) {
        Button button = new Button(text);
        button.setStyle("-fx-background-color: #90caf9; -fx-text-fill: white;");
        button.setMinSize(150, 50); // Set a fixed size for all buttons
        return button;
    }
}