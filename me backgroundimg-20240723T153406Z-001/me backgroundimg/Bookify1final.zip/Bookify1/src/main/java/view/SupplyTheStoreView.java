package view;

import controller.BillController;
import controller.BookController;
import controller.EmployeeController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.beans.binding.BooleanBinding;
import model.Book;
import model.Employee;

public class SupplyTheStoreView {
    private Employee currentUser;
    private BookController bookController;
    private BillController billController;
    private EmployeeController employeeController;
    public SupplyTheStoreView(BillController billController, BookController bookController, EmployeeController employeeController, Employee currentUser){
        this.currentUser=currentUser;
        this.billController=billController;
        this.bookController=bookController;
        this.employeeController=employeeController;


    }



    public Scene viewSupply(Stage stage) {
        GridPane gridPane1 = new GridPane();
        gridPane1.setAlignment(Pos.CENTER);
        gridPane1.setPadding(new Insets(11.5, 11.5, 11.5, 11.5));
        gridPane1.setHgap(8);
        gridPane1.setVgap(5);

        Button search = new Button("Search");

        search.setStyle("-fx-font-size: 20px;-fx-background-color: #90caf9; -fx-text-fill: white;");


        Button back = new Button("Back");
        back.setStyle("-fx-font-size: 20px;-fx-background-color: #90caf9; -fx-text-fill: white;");
// Set a larger font size

        TextField ISBN = createTextFieldWithPrompt("ISBN");
        ISBN.setStyle("-fx-font-size: 20px;"); // Set a larger font size
Label l1=new Label("Enter the ISBN");
        l1.setStyle("-fx-font-size: 20px;"); // Set a larger font size

        gridPane1.add(l1, 0, 0);
        gridPane1.add(ISBN, 1, 0);
        gridPane1.add(search, 2, 0);
        gridPane1.add(back, 2, 2);

        search.setDisable(true);

        BooleanBinding isISBNEmpty = ISBN.textProperty().isEmpty();
        search.disableProperty().bind(isISBNEmpty);



        search.setOnAction(e->{
            String ISBN1 = ISBN.getText();
            if (ISBN1.isEmpty()) {
                showAlert("Error", "Please enter an ISBN before searching.");
                return;
            }

            Book book=bookController.serchIsbn(ISBN1);
            int index= BookController.getIndex();
            if (book==null){
                AddNewBook addnewbook=new AddNewBook(this.billController,this.bookController,this.employeeController,this.currentUser);
                stage.setScene(addnewbook.viewSupply(stage ,ISBN1));
            }
            else if(book.getISBN().equals(ISBN1)){

                AddExistingBookView addExistingBookVie=new AddExistingBookView(this.billController,this.bookController,this.employeeController,this.currentUser);
                stage.setScene(addExistingBookVie.viewSupply(stage));
                //   managerController.Show_manager_homeview(stage);
                // stage.setScene(managerController.Show_manager_homeview(stage));
            }


        });
        back.setOnAction(e->{

            if(currentUser.getNr()==0) {
                AdministratorHomePageView hv2 = new AdministratorHomePageView(billController,bookController,employeeController,currentUser);
                stage.setTitle("AdministratorHomePageView");

                stage.setScene(hv2.showView(stage));
                System.out.println("0");
            }
            else if (currentUser.getNr()==1){
                ManagerHomePageView homePageView=new ManagerHomePageView(billController,bookController,employeeController,currentUser);
                stage.setTitle("ManagerHomePage");
                stage.setScene(homePageView.showView(stage));
            }else{
                LibrarianHomePageView homePageView=new LibrarianHomePageView(billController,bookController,employeeController,currentUser);
                stage.setTitle("LibrarianHomePageView");
                stage.setScene(homePageView.showView(stage));
            }
            System.out.println("898");
        });
        Image backgroundImage = new Image("Photo/Fotohomepage1.jpg");

        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);

        // Set the background image to the grid pane
        gridPane1.setBackground(new Background(background));

        Scene scene = new Scene(gridPane1, 1079, 771);

        return scene;
    }

    private TextField createTextFieldWithPrompt(String prompt) {
        TextField textField = new TextField();
        textField.setPromptText(prompt);

        // Add a listener to hide the prompt text when the user starts typing
        textField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.isEmpty()) {
                textField.setPromptText("");
            } else {
                textField.setPromptText(prompt);
            }
        });

        return textField;
    }

    private Button createStyledButton(String text) {
        Button button = new Button(text);
        button.setStyle("-fx-background-color: #90caf9; -fx-text-fill: white;");
        return button;
    }

    private void validateISBN(String ISBN) {
        if (!ISBN.matches("\\d*")) {
            showAlert("Invalid Purchase Price", "Purchase Price should contain only numbers.");
        }
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();}

}