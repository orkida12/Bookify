package view;

import controller.BillController;
import controller.BookController;
import controller.EmployeeController;
import javafx.beans.binding.BooleanBinding;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import model.Employee;

public class AddExistingBookView {
    private Employee currentUser;
    private BookController bookController;
    private BillController billController;
    private EmployeeController employeeController;

    public AddExistingBookView(BillController billController, BookController bookController,
                               EmployeeController employeeController, Employee currentUser) {
        this.currentUser = currentUser;
        this.billController = billController;
        this.bookController = bookController;
        this.employeeController = employeeController;
    }

    public Scene viewSupply(Stage stage) {
        GridPane gridPane1 = new GridPane();
        gridPane1.setAlignment(Pos.CENTER);
        gridPane1.setPadding(new Insets(11.5, 11.5, 11.5, 11.5));
        gridPane1.setHgap(8);
        gridPane1.setVgap(5);

        TextField q = new TextField();
        q.setStyle("-fx-font-size: 20px;"); // Set a larger font size

        Button add = new Button("Add");
        add.setStyle("-fx-font-size: 20px;-fx-background-color: #90caf9; -fx-text-fill: white;");


        add.setDisable(true); // Disable the button initially

        Label has_Isbn = new Label("Supply existing book");
        has_Isbn.setStyle("-fx-font-size: 20px;"); // Set a larger font size

        Label quantity = new Label("Enter the quantity");
        quantity.setStyle("-fx-font-size: 20px;"); // Set a larger font size


        gridPane1.add(has_Isbn, 1, 0, 3, 1); // Spanning multiple columns for centering
        gridPane1.add(quantity, 0, 1);
        gridPane1.add(q, 1, 1);
        gridPane1.add(add, 2, 1);

        BooleanBinding isQEmpty = q.textProperty().isEmpty();
        add.disableProperty().bind(isQEmpty);
        add.setOnAction(e->{

            String quatity2 = q.getText();
            int stock2 = 0;

            try {
                stock2 = Integer.parseInt(quatity2);
                //   managerController.add_existing_book(stock);
                bookController.add_existing_book1(stock2);
                Alert infromation = new Alert(Alert.AlertType.INFORMATION);
                infromation.setHeaderText("The quantity of the book was added successfully");
                infromation.showAndWait();
                SupplyTheStoreView a=new SupplyTheStoreView(this.billController,this.bookController,this.employeeController,this.currentUser);
                stage.setScene(a.viewSupply(stage));
            } catch (NumberFormatException exception) {
                Alert error = new Alert(Alert.AlertType.ERROR);
                error.setHeaderText("Enter a number!");
                error.showAndWait();


                ManagerHomePageView managerHomePageView=new ManagerHomePageView(this.billController,this.bookController,this.employeeController,this.currentUser);
                stage.setScene(managerHomePageView.showView(stage));
         }

        });

        q.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.isEmpty()) {
                validateQ(newValue);
            }
        });
        Image backgroundImage = new Image("Photo/Fotohomepage1.jpg");

        // Create a background image
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);

        // Set the background image to the grid pane
        gridPane1.setBackground(new Background(background));
        Scene scene = new Scene(gridPane1, 1079, 771);
        return scene;
    }

    private Button createStyledButton(String text) {
        Button button = new Button(text);
        button.setStyle("-fx-background-color: #2196F3; -fx-text-fill: white;");
        return button;
    }


    private void validateQ(String q) {
        if (!q.matches("\\d*")) {
            showAlert("Invalid Quantity", "Quantity should contain only numbers.");
        }
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
}
}