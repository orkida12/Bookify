package view;

import controller.BillController;
import controller.BookController;
import controller.EmployeeController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import model.Employee;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class FinanceView {
    private Employee currentUser;
    private BookController bookController;
    private BillController billController;
    private EmployeeController employeeController;

    public FinanceView(BillController billController, BookController bookController, EmployeeController employeeController, Employee currentUser) {
        this.currentUser = currentUser;
        this.billController = billController;
        this.bookController = bookController;
        this.employeeController = employeeController;
    }

    public Scene showView(Stage stage) {
        // Scene 1: Search Scene
        stage.setTitle("Finance Date Picker");

        GridPane searchSceneGrid = new GridPane();
        searchSceneGrid.setPadding(new Insets(10, 10, 10, 10));
        searchSceneGrid.setAlignment(Pos.CENTER);

        searchSceneGrid.setVgap(8);
        searchSceneGrid.setHgap(10);

        Label label = new Label("Search");
        label.setStyle("-fx-font-size: 70px;"); // Set a larger font size

        DatePicker startDatePicker = new DatePicker();
        DatePicker endDatePicker = new DatePicker();
        startDatePicker.setMinSize(150, 50); // Set a fixed size for all buttons
        endDatePicker.setMinSize(150, 50); // Set a fixed size for all buttons

        Button searchButton = new Button("Search");
        Button back = new Button("Back");
        searchButton.setMinSize(150, 50); // Set a fixed size for all buttons
        back.setMinSize(150, 50); // Set a fixed size for all buttons


        // Place controls in the grid
        searchSceneGrid.add(label, 0, 0, 3, 1); // Label spans across 3 columns
        searchSceneGrid.add(startDatePicker, 1, 1);
        searchSceneGrid.add(endDatePicker, 2, 1);
        searchSceneGrid.add(searchButton, 3, 1);
        searchSceneGrid.add(back, 4, 1);
        searchButton.setStyle("-fx-background-color: #90caf9; -fx-text-fill: white;"); // Set button color and text color
        back.setStyle("-fx-background-color: #90caf9; -fx-text-fill: white;"); // Set button color and text color
        // Enable the search button only if both start and end dates are selected
        startDatePicker.setOnAction(event -> {
            updateSearchButtonState(startDatePicker, endDatePicker, searchButton);
        });

        endDatePicker.setOnAction(event -> {
            updateSearchButtonState(startDatePicker, endDatePicker, searchButton);
        });

        searchButton.setOnAction(e -> {
            LocalDate startDate = startDatePicker.getValue();
            LocalDate endDate = endDatePicker.getValue();
            long daysBetween = 0;
            if (startDate != null && endDate != null) {

                System.out.println("Start Date: " + startDate);
                System.out.println("End Date: " + endDate);
                 daysBetween = ChronoUnit.DAYS.between(startDate, endDate);
                for (int i = 0; i <= daysBetween; i++) {
                    LocalDate currentDate = startDate.plusDays(i);
                    
                }
            }

            IncomeCostView a = new IncomeCostView(billController, bookController, employeeController, currentUser);
            stage.setScene(a.showView(stage,daysBetween));
        });

        back.setOnAction(e -> {
            AdministratorHomePageView sv = new AdministratorHomePageView(billController, bookController, employeeController, currentUser);
            stage.setScene(sv.showView(stage));
        });

        Image backgroundImage = new Image("Photo/Fotohomepage1.jpg");

        // Create a background image
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);

        // Set the background image to the grid pane
        searchSceneGrid.setBackground(new Background(background));
        Scene searchScene =new Scene(searchSceneGrid, 1079, 771);

        return searchScene;
}
    private void updateSearchButtonState(DatePicker startDatePicker, DatePicker endDatePicker, Button searchButton) {
        LocalDate startDate = startDatePicker.getValue();
        LocalDate endDate = endDatePicker.getValue();

        // Enable the search button only if both start and end dates are selected
        searchButton.setDisable(startDate == null || endDate == null);
}
    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }


}