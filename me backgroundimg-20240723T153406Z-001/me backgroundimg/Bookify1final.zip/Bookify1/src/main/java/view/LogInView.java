package view;

import controller.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import model.Employee;


public class LogInView {
    private BookController bookController;
    private BillController billController;
    private EmployeeController employeeController;
    public LogInView() {
        this.bookController = new BookController();
        this.billController = new BillController();
        this.employeeController = new EmployeeController();
        //   this.billController=new BillController();

    }

    public BillController getBillController() {
        return billController;
    }

    public BookController getBookController() {
        return bookController;
    }

    public EmployeeController getEmployeeController() {
        return employeeController;
    }


    public Scene showView(Stage stage) {
        GridPane p = new GridPane();
        p.setHgap(10);
        p.setVgap(10);
        p.setPadding(new Insets(10, 10, 10, 10));
        p.setAlignment(Pos.CENTER);

        Label username = new Label("Username");
        username.setStyle("-fx-text-fill: white; -fx-font-size: 16px;");
        TextField usernameF = new TextField();
        usernameF.setStyle("-fx-font-size: 16px;");
        p.add(username, 0, 0);
        p.add(usernameF, 1, 0);

        Label passw = new Label("Password");
        passw.setStyle("-fx-text-fill: white; -fx-font-size: 16px;");
        PasswordField passwF = new PasswordField();
        passwF.setStyle("-fx-font-size: 16px;");
        p.add(passw, 0, 1);
        p.add(passwF, 1, 1);

        Button login = new Button("Log in");
        login.setStyle("-fx-font-size: 16px; -fx-background-color: white; -fx-text-fill: black;");
        login.setPrefWidth(200);

        HBox h = new HBox();
        h.getChildren().add(login);
        h.setSpacing(10);
        p.add(h, 1, 3);

        login.setOnAction(e -> {
            Employee user = employeeController.login(usernameF.getText(), passwF.getText());

            if (user != null) {
                Alert al = new Alert(Alert.AlertType.INFORMATION);
                al.setHeaderText("You entered successfully");
                al.showAndWait();

                if (user.getNr() == 0) {
                    AdministratorHomePageView hv2 = new AdministratorHomePageView(billController, bookController,
                            employeeController, user);
                    stage.setTitle("AdministratorHomePageView");

                    stage.setScene(hv2.showView(stage));
                } else if (user.getNr() == 1) {
                    ManagerHomePageView homePageView = new ManagerHomePageView(billController, bookController,
                            employeeController, user);
                    stage.setTitle("ManagerHomePage");
                    stage.setScene(homePageView.showView(stage));
                } else {
                    LibrarianHomePageView homePageView = new LibrarianHomePageView(billController, bookController,
                            employeeController, user);
                    stage.setTitle("LibrarianHomePageView");
                    stage.setScene(homePageView.showView(stage));
                }
                System.out.println("898");
            } else {
                Alert al = new Alert(Alert.AlertType.ERROR);
                al.setHeaderText("Enter the correct email and passw");
                al.showAndWait();
            }
        });



        Image backgroundImage = new Image("/Photo/loginbookify1.jpg");

        // Create a background image
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);

        // Set the background image to the grid pane
        p.setBackground(new Background(background));




        Scene sc = new Scene(p, 1079, 771);

        return sc;
    }
}