package model;

public class Librarian {
    private String username;
    private int nr_bills;
    private int book_sold;
    private double total_amountMoney;

    public Librarian(String username,int nr_bills,int book_sold,double total_amountMoney){
        this.nr_bills=nr_bills;
        this.book_sold=book_sold;
        this.total_amountMoney=total_amountMoney;
        this.username=username;
    }

    public int getNr_bills() {
        return nr_bills;
    }

    public int getBook_sold() {
        return book_sold;
    }

    public double getTotal_amountMoney() {
        return total_amountMoney;
    }

    public String getUsername() {
        return username;
    }

    public void setNr_bills(int nr_bills) {
        this.nr_bills = nr_bills;
    }

    public void setBook_sold(int book_sold) {
        this.book_sold = book_sold;
    }

    public void setTotal_amountMoney(double total_amountMoney) {
        this.total_amountMoney = total_amountMoney;
    }

    public void setUsername(String username) {
        this.username = username;
}
}