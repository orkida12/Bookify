package model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;


public class Employee implements Serializable {
    private static final long serialVersionUID = -3292385108400454436L;
    private String firstName, lastName, gendre, role, username, password, email;

    private int phone;
    private LocalDate birthday;
    private double salary;
    int nr;
    Date dateregistered;
    int nrcreatebill;
    int nrsearchstore;
    int nrbillhistory;
    int nrsupply;
    int nrlowstock;
    int nrstatistics;
    int nrlperformance;



    public Employee() {

    }

    public Employee(String firstName, String lastName, String email, String password, String gendre, String role, LocalDate birthday, int phone, String username,double salary) {
        super();
        this.firstName = firstName;
        this.email = email;
        this.password = password;
        this.lastName = lastName;
        this.gendre = gendre;
        this.birthday = birthday;
        this.phone = phone;
        this.role = role;
        this.username = username;
        this.dateregistered=new Date();
        if (role.equals("Librarian")) {
            this.nr = 3;
            this.nrsupply = 0;
            this.nrstatistics = 0;
            this.nrlperformance = 0;
            this.nrlowstock=0;
            this.nrcreatebill=1;
            this.nrsearchstore=1;
            this.nrbillhistory=1;
        } else if (role.equals("Manager")) {
            this.nr = 1;
            this.nrcreatebill=0;
            this.nrsearchstore=0;
            this.nrbillhistory=0;
            this.nrsupply = 1;
            this.nrstatistics = 1;
            this.nrlperformance = 1;
            this.nrlowstock=1;
        } else  {

            this.nr = 0;

        }



        this.salary=salary;


    }
    public int getNrcreatebill() {
        return nrcreatebill;
    }

    public int getNrsearchstore() {
        return nrsearchstore;
    }

    public int getNrbillhistory() {
        return nrbillhistory;
    }

    public int getNrlowstock() {
        return nrlowstock;
    }

    public int getNrlperformance() {
        return nrlperformance;
    }

    public int getNrstatistics() {
        return nrstatistics;
    }

    public int getNrsupply() {
        return nrsupply;
    }

    public void setNrbillhistory(int nrbillhistory) {
        this.nrbillhistory = nrbillhistory;
    }

    public void setNrcreatebill(int nrcreatebill) {
        this.nrcreatebill = nrcreatebill;
    }

    public void setNrlowstock(int nrlowstock) {
        this.nrlowstock = nrlowstock;
    }

    public void setNrsearchstore(int nrsearchstore) {
        this.nrsearchstore = nrsearchstore;
    }

    public void setNrlperformance(int nrlperformance) {
        this.nrlperformance = nrlperformance;
    }

    public void setNrstatistics(int nrstatistics) {
        this.nrstatistics = nrstatistics;
    }

    public void setNrsupply(int nrsupply) {
        this.nrsupply = nrsupply;
    }


    public int getNr() {
        return nr;
    }

    public void setNr(int nr) {
        this.nr = nr;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setGenre(String genre) {
        this.gendre = genre;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }


    public void setBirthday(LocalDate birthday) {
        this.birthday = birthday;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public int getPhone() {
        return phone;
    }


    public String getEmail() {
        return email;
    }

    public LocalDate getBirthday() {
        return birthday;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getGenre() {
        return gendre;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPassword() {
        return password;
    }


    public String getRole() {
        return role;
    }


    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public Date getDateregistered() {
        return dateregistered;
    }

    public void setDateregistered(Date dateregistered) {
        this.dateregistered = dateregistered;
    }

    public String toString() {
        return "User [firstName=" + this.firstName + ", lastName=" + this.lastName + ", email=" + this.email + ", password=" + this.password + ", genre=" + this.gendre + ", salary=" + this.salary + "]";
    }
}