package controller;

import model.Employee;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class EmployeeController {

    private ArrayList<Employee> employee;
    private ArrayList<Employee> arraylist_lib;
    private File file;//normal file

    // Binary files can be used to store various types of data, including images, audio, video, and serialized objects
    public EmployeeController() {
        employee = new ArrayList<>();
        arraylist_lib=new ArrayList<>();

        file = new File("Database/employee.dat");
        if (file.exists()) {
            readEmployee();
        }
    }
    private void readEmployee() {
        try {
            FileInputStream fis = new FileInputStream(file);
            ObjectInputStream ois = new ObjectInputStream(fis);
            employee = (ArrayList<Employee>) ois.readObject();
            fis.close();
            ois.close();

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    public void writeEmployee() {
        try {
            FileOutputStream fos = new FileOutputStream(file);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(employee);
            oos.close();
            fos.close();

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void addEmployee(Employee employees) {
        employee.add(employees);

    }

    public void removeEmployee(Employee employees) {
        employee.remove(employees);

    }

    public void modifyEmployee(Employee oldEmployee, Employee newEmployee) {
        int index = employee.indexOf(oldEmployee);
        if (index != -1) {
            employee.set(index, newEmployee);
        }
        print();



    }
    public static void getcalculateTotalSalary(ArrayList<Employee> users) {
        double totalSalary = 0;

        for (Employee user : users) {
            totalSalary += user.getSalary();
        }
    }
    public ArrayList<Employee> getEmployees() {
        return new ArrayList<>(employee);
    }
    public ArrayList<Employee> getLibList(){
        for (Employee L:employee){
            // if(L.getRole().equals("Librarians")){
            //      arraylist_lib.add(L);
            // }
            if(L.getNr()==3){
                arraylist_lib.add(L);
            }
        }
        return arraylist_lib;
    }
    public String getLibListUsername(Employee em){

        for (Employee L:employee){

            if((L.getUsername()).equals(em.getUsername()))
                return L.getUsername();

        }
        return null;

    }


    public Employee login(String Username, String password) {
        for (Employee user : employee) {
            if (user.getUsername().equals(Username) && user.getPassword().equals(password)) {
                return user;
            }
        }
        return null;
    }
    public void print() {
        for(int i = 0; i < this.employee.size(); ++i) {
            System.out.println(this.employee.get(i));
        }

    }
    public boolean searchUsername(String Username){
        for(int i = 0; i < this.employee.size(); ++i) {

            if(employee.get(i).getUsername().equals(Username)){
                return true;
            }
        }
        return false;
    }
    public Employee searchUsername1(String Username){
        for(int i = 0; i < this.employee.size(); ++i) {

            if(employee.get(i).getUsername().equals(Username)){
                return employee.get(i);
            }
        }
        return null;
    }
    public boolean checkIfLib(String id) {
        for (int i = 0; i < employee.size(); i++) {
            if (id.equals(employee.get(i).getUsername())){
                if(employee.get(i).getNr()==3){
                    return true;
                }
            }
        }
        return false;
 }

}

