package controller;


import model.Book;

import java.io.*;
import java.util.ArrayList;
import java.util.Date;

public class BookController {

    private ArrayList<Book> book_arraylist;
    private File file;
    private static int index;
    public BookController(){

        book_arraylist = new ArrayList<>();

        file = new File("Database/book.dat");//.bin e ka per binary file
        if (file.exists()) {
            readBook();
        }
    }


    public static int getIndex() {
        return index;
    }

    public ArrayList<Book> getBook_arraylist() {
        return book_arraylist;
    }
    public String getIsbn(int i){
        return book_arraylist.get(i).getISBN();
    }
    public String getTitle(int i){
        return book_arraylist.get(i).getTitle();
    }
    public String getAuthor(int i){
        return book_arraylist.get(i).getAuthor();
    }
    public String getCategory(int i){
        return book_arraylist.get(i).getCategory();
    }
    public String getSupplier(int i){
        return book_arraylist.get(i).getSupplier();
    }
    public double getPurchesPrice(int i){
        return book_arraylist.get(i).getPurchasePrice();
    }
    public double getSellingPrice(int i){return book_arraylist.get(i).getPurchasePrice();}



    public Date getPurchesDate(int i){
        return book_arraylist.get(i).getPurchaseDate();
    }


    public int getStock(int i){
        return book_arraylist.get(i).getStock();
    }
    public boolean check_stock1(int i ){
        if(book_arraylist.get(i).getStock()<=5){
            return true;
        }
        return false;
    }

    private void readBook() {
        try {
            FileInputStream fis = new FileInputStream(file);
            ObjectInputStream ois = new ObjectInputStream(fis);
            book_arraylist = (ArrayList<Book>) ois.readObject();
            fis.close();
            ois.close();

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    private void writeBook() {
        try {
            FileOutputStream fos = new FileOutputStream(file);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(book_arraylist);
            oos.close();
            fos.close();

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    public void add_existing_book1(int stock){
        (this.book_arraylist.get(index)).setStock(stock+book_arraylist.get(index).getStock());
        System.out.println(book_arraylist.toString());



    }
    public void create_new_book(String ISBN, String title, String category, String supplier,
                                double purchasePrice, double sellingPrice, String author, int stock){
        Book book=new Book(ISBN,title,category,supplier,purchasePrice,sellingPrice,author,stock);
        this.book_arraylist.add(book);
        //write_books();
        System.out.println(book_arraylist);
        writeBook();

        //book_arraylist.add(new Book(ISBN,title,category,supplier,purchasePrice,originalPrice,sellingPrice,author,stock,bookCoverImage));
    }


    public Book serchIsbn(String isbn) {
        for(int i=0;i<book_arraylist.size();i++){
            if(book_arraylist.get(i).getISBN().equals(isbn)){
                index=i;
                return book_arraylist.get(i);

            }
        }

        return null;

    }
    public boolean check_stock(int i ){
        if(book_arraylist.get(i).getStock()<=5){
            return true;
        }
        return false;
    }
    public boolean stock_alarm(){
        for (int i=0;i<book_arraylist.size();i++){
            if(book_arraylist.get(i).getStock()<=5){
                return true;
            }
        }
        return false;
    }
    public Book getMostSold(){
        int max=0;
        for(int i=1;i<book_arraylist.size();i++){
            if(book_arraylist.get(max).getCnt()<book_arraylist.get(i).getCnt()){
                max=i;
            }
        }
        System.out.println("Max"+book_arraylist.get(max));
        return book_arraylist.get(max);
    }
    public Book getLeastSold(){
        int max=0;
        for(int i=1;i<book_arraylist.size();i++){
            if(book_arraylist.get(max).getCnt()>book_arraylist.get(i).getCnt()){
                max=i;
            }
        }
        System.out.println("Min"+book_arraylist.get(max));
        return book_arraylist.get(max);
}
    public  void setcnt(int quantity,String ISBN){
        for(int i=0;i<book_arraylist.size();i++){
            if(ISBN.equals(book_arraylist.get(i).getISBN())){
                System.out.println("U plotesua kushti");
                (book_arraylist.get(i)).setCnt(book_arraylist.get(i).getCnt()+quantity);
                System.out.println(book_arraylist.get(i));
                return;
            }
        }
    }



}