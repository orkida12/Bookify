package controller;

import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import model.Bill;
import model.Book;
import model.Employee;
import view.*;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AdministratorController  {

    private EmployeeController employeeManager;
    private EmployeeListView listView;
    private AddModifyEmployeeView formView;
    private LogInView variable;
    RadioButton newBill;
    RadioButton searchTheStore;
    RadioButton billHistory;
    RadioButton supplyTheStore;
    RadioButton lowStock;
    RadioButton Lperformance;
    RadioButton statistics;
    public AdministratorController(LogInView variable){
        this.variable=variable;
    }

    public AdministratorController(EmployeeController employeeManager, EmployeeListView listView,
                                   AddModifyEmployeeView formView) {
        this.employeeManager = employeeManager;
        this.listView = listView;
        this.formView = formView;

    }
    public void updateEmployeeList() {
        employeeManager.getEmployees();
        listView.clearList();
        listView.displayEmployees(employeeManager.getEmployees());




    }
    public void showEmployeeList() {
        updateEmployeeList();
    }

    public void addEmployee() {
        Employee newEmployee = formView.
                getEmployeeInput();

        employeeManager.addEmployee(newEmployee);
        formView.clearFields();
        showEmployeeList();


    }

    public void removeEmployee(Employee employee) {
        employeeManager.removeEmployee(employee);
        showEmployeeList();
    }

    public void modifyEmployee(Employee oldEmployee, Employee newEmployee) {
        employeeManager.modifyEmployee(oldEmployee, newEmployee);
        showEmployeeList();
    }
    public void addmodifyEmployee(Employee newEmployee) {
        employeeManager.addEmployee(newEmployee);

    }

    public double calculateTotalSalary() {
        double totalSalary = 0;
        for (Employee user : variable.getEmployeeController().getEmployees()) {
            totalSalary += user.getSalary();
        }

        return totalSalary;
    }
    public int totalbooksold() {
        int totalbook = 0;
        try{
            for (Bill bill : variable.getBillController().getBill()) {
                for (int i = 0; i < bill.getNr_items(); i++)
                    totalbook += bill.getNr_items();
            }

            return totalbook;}
        catch (NullPointerException e){}
        return 0;
    }
    public double sumofpricesold() {
        double totalbook = 0;
        for (Bill bill : variable.getBillController().getBill()) {

            totalbook += bill.getTotal_price();
        }

        return totalbook;
    }
    public int totalbookbought(){
        int totalbook = 0;
        for (Book book : variable.getBookController().getBook_arraylist()) {

            totalbook += book.getStock();
        }

        return totalbook;

    }
    public double sumtotalbookbought(){
        double totalbook = 0;
        for (Book bill : variable.getBookController().getBook_arraylist()) {

            totalbook +=(bill.getPurchasePrice()* bill.getStock());
        }

        return totalbook;

    }

    public  int  getArraySize() {
        return  variable.getEmployeeController().getEmployees().size();
    }
    public ArrayList<Bill> check_bills(LocalDate userDate){
        ArrayList<Bill> Billsneeded = new ArrayList<>();

        for (int i=0;i<variable.getBillController().getBill().size();i++){

            if(userDate.equals(variable.getBillController().getBill().get(i).getBil_date().toInstant().atZone(ZoneId.systemDefault()).toLocalDate())){
                Bill Billgjetur = variable.getBillController().getBill().get(i);
                Billsneeded.add(Billgjetur);

            }

        }
        return Billsneeded;
    }



}
